# Text Expander (Linux)

A small desktop helper for Linux, written in Rust. It runs in the background and adds four things you can use in any program:

| Tab | What it does | Default shortcut |
|---|---|---|
| **Text expander** | Type a short trigger (for example `omy`) and it becomes a longer text (`on my way`). Each trigger can need a Space or expand instantly. | – |
| **OCR** | Select an area of the screen and its text is copied to the clipboard. | `Ctrl+Alt+O` |
| **Voice typing** | Offline speech-to-text for **Danish and English**. Shows what you say in a live box, can type phrase by phrase, and can show an edit box so you can correct the text before it is typed. | `Ctrl+Alt+V` |
| **Read aloud** | Select text in any program and have it read out loud (Danish or English voice), with stop and pause/resume. | `Ctrl+Alt+D` (Danish), `Ctrl+Alt+E` (English), `Ctrl+Alt+S` (stop), `Ctrl+Alt+P` (pause/resume) |

Everything runs on your own computer. The settings window is available in English and Danish.

## Status

**Experimental.** It was developed and tested on **Fedora KDE Plasma (Wayland)** only. Other desktops may work partly (some features use KDE's Klipper and Spectacle). The OCR, voice typing and read-aloud features are Linux-only. There is no Windows or macOS installer; the source contains early, untested support for the text expander on those systems. Expect rough edges, and please open an issue if something breaks.

## Requirements

- Linux with a Wayland or X11 desktop (KDE Plasma recommended)
- `sudo` once, to install packages and a keyboard-access rule
- Internet during installation, and a few GB of free disk space (the Parakeet speech model is about 670 MB, each reading voice about 63 MB; the first build takes a few minutes)

## Install

```bash
git clone https://github.com/<your-name>/text-expander.git
cd text-expander
bash install.sh
```

The installer asks for your password when needed. It:

1. installs build tools and helpers (Rust, a C++ compiler, cmake, Tesseract, wl-clipboard, sound tools, Python) with `dnf`, `apt` or `pacman`;
2. builds the program and puts it in `~/.local/bin`;
3. builds the offline speech engines (whisper.cpp) and sets up a private Python for the fast Parakeet engine and the Piper voices;
4. adds you to the `input` group and a `uinput` rule, so the program can see global shortcuts and type text on Wayland;
5. creates a menu entry, entries for KDE shortcuts, and a systemd user service so it starts at login.

**Log out and back in once** after the first install (the `input` group needs it). Then open **Text Expander** from your application menu.

First use:
- *Voice typing*: open the tab and press **Download** on the first model (Parakeet).
- *Read aloud*: open the tab and download one Danish and one English voice.
- *OCR*: works as soon as the packages are installed.

The window title shows the version, for example `Text Expander v0.16.0`.

## Shortcuts that type a letter

The program watches the keyboard but cannot hide a key from other programs. If a shortcut such as `Ctrl+Alt+D` types a letter into your document:

- use a key that types nothing, for example `F9`, or
- let KDE handle the shortcut: **System Settings → Keyboard → Shortcuts → Add Command**, with one of:

```
~/.local/bin/expander --voice-toggle     # start/stop voice typing
~/.local/bin/expander --voice-start
~/.local/bin/expander --voice-stop
~/.local/bin/expander --ocr
~/.local/bin/expander --read-da          # read the selection in Danish
~/.local/bin/expander --read-en          # read the selection in English
~/.local/bin/expander --read-stop
~/.local/bin/expander --read-pause
```

## Privacy and security

- Speech recognition, OCR and the reading voices run locally. The only network use is downloading: the program source and models from GitHub and Hugging Face, and Python packages from PyPI.
- To support global shortcuts and trigger words on Wayland, the program reads keyboard events from `/dev/input` and types through a virtual keyboard (`/dev/uinput`). It keeps only a short buffer of recent characters to match triggers and does not store what you type. Be aware that membership of the `input` group lets *any* program you run read keyboard events, so only install this if you are comfortable with that. The code is here to be inspected.

## Files and logs

- Settings and logs: `~/.config/expander/` (`triggers.json`, `voice.json`, `ocr.json`, `speak.json`, `expander.log`, `parakeet-server.log`, `tts-server.log`)
- Models, voices and the private Python: `~/.local/share/expander/`
- Python setup log: `~/.local/share/expander/python-setup.log`; build log: `build.log`

If the Python setup fails, run `scripts/setup-fast-engine.sh` (speech) and `scripts/setup-reading-voice.sh` (voices) and read the log it prints. The fast speech engine needs Python 3.10–3.14; if your system Python is newer, the script downloads a private Python 3.13.

## Uninstall

```bash
systemctl --user disable --now expander.service
rm -f ~/.local/bin/expander ~/.config/systemd/user/expander.service
rm -f ~/.local/share/applications/expander*.desktop
rm -rf ~/.config/expander ~/.local/share/expander
sudo rm -f /etc/udev/rules.d/99-uinput.rules /etc/modules-load.d/uinput.conf
sudo gpasswd -d "$USER" input
```

## Credits and licenses

This project is licensed under the MIT License (see `LICENSE`). It downloads and uses other software and models, each under its own license. As far as I know, and please check each project's page before you redistribute anything:

- [whisper.cpp](https://github.com/ggml-org/whisper.cpp) (MIT) – speech engine for the Whisper models
- NVIDIA Parakeet TDT 0.6B v3 (see its model card; used through [onnx-asr](https://github.com/istupakov/onnx-asr) and the GGUF files from `ggml-org/parakeet-GGUF`)
- [Piper](https://github.com/OHF-Voice/piper1-gpl) (GPL, installed as a separate Python package and run as a separate process) and the Piper voices from `rhasspy/piper-voices` (each voice has its own license on its model card)
- [Tesseract](https://github.com/tesseract-ocr/tesseract) (Apache-2.0) for OCR
- Rust crates such as `egui`/`eframe`, `rdev`, `enigo`, `evdev`, `serde`

The design of the voice typing (offline Parakeet, a live box, typing at pauses) was inspired by [TuxTalk](https://github.com/ronb1964/TuxTalk). No TuxTalk code was used.

This project was developed with the help of an AI assistant (Claude, by Anthropic).
