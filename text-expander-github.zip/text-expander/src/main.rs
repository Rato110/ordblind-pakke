#![cfg_attr(windows, windows_subsystem = "windows")]

use eframe::egui;
use serde::{Deserialize, Serialize};
use std::{
    fs,
    path::PathBuf,
    process::{Command, Stdio},
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc, Mutex,
    },
    thread,
    time::{Duration, Instant, SystemTime},
};

#[derive(Serialize, Deserialize, Clone)]
struct Entry {
    trigger: String,
    text: String,
    // true: expands when you type the trigger and press Space
    // false: expands instantly as soon as the trigger is typed
    #[serde(default = "default_true")]
    space: bool,
}

fn default_true() -> bool {
    true
}

type Shared = Arc<Mutex<Vec<Entry>>>;
// "auto" or a layout code: "dk", "us", "uk", "fi"
type LayoutSetting = Arc<Mutex<String>>;

// OCR (copy the text of a selected screen area to the clipboard) settings
#[derive(Serialize, Deserialize, Clone)]
struct OcrConfig {
    #[serde(default = "default_true")]
    enabled: bool,
    #[serde(default = "default_ocr_shortcut")]
    shortcut: String,
    #[serde(default = "default_ocr_languages")]
    languages: String,
}

fn default_ocr_shortcut() -> String {
    "Ctrl+Alt+O".to_string()
}

fn default_ocr_languages() -> String {
    "eng+dan".to_string()
}

impl Default for OcrConfig {
    fn default() -> Self {
        OcrConfig {
            enabled: true,
            shortcut: default_ocr_shortcut(),
            languages: default_ocr_languages(),
        }
    }
}

type OcrShared = Arc<Mutex<OcrConfig>>;

// Voice typing (offline speech-to-text) settings
#[derive(Serialize, Deserialize, Clone)]
struct VoiceConfig {
    #[serde(default = "default_true")]
    enabled: bool,
    #[serde(default = "default_voice_shortcut")]
    shortcut: String,
    // "toggle": press to start, press again to stop. "hold": record while the key is held
    #[serde(default = "default_voice_mode")]
    mode: String,
    // "da", "en" or "auto" (used by the Whisper models; Parakeet detects the language itself)
    #[serde(default = "default_voice_language")]
    language: String,
    #[serde(default = "default_voice_model")]
    model: String,
    // show the text on screen while speaking
    #[serde(default)]
    live: bool,
    // "box" (window on screen) or "notification"
    #[serde(default = "default_live_style")]
    live_style: String,
    // short beeps when listening starts and stops
    #[serde(default = "default_true")]
    sounds: bool,
    // type each phrase as soon as the speaker pauses (toggle mode only)
    #[serde(default = "default_true")]
    type_live: bool,
    // how long a pause (in milliseconds) ends a phrase
    #[serde(default = "default_pause_ms")]
    pause_ms: u32,
    // show the text in a box where it can be corrected before it is typed
    #[serde(default)]
    review: bool,
}

fn default_voice_shortcut() -> String {
    "Ctrl+Alt+V".to_string()
}

fn default_voice_mode() -> String {
    "toggle".to_string()
}

fn default_voice_language() -> String {
    "da".to_string()
}

fn default_voice_model() -> String {
    "parakeet-onnx".to_string()
}

fn default_live_style() -> String {
    "box".to_string()
}

fn default_pause_ms() -> u32 {
    450
}

impl Default for VoiceConfig {
    fn default() -> Self {
        VoiceConfig {
            enabled: true,
            shortcut: default_voice_shortcut(),
            mode: default_voice_mode(),
            language: default_voice_language(),
            model: default_voice_model(),
            live: false,
            live_style: default_live_style(),
            sounds: true,
            type_live: true,
            pause_ms: default_pause_ms(),
            review: false,
        }
    }
}

type VoiceShared = Arc<Mutex<VoiceConfig>>;

// Read aloud (text to speech) settings
#[derive(Serialize, Deserialize, Clone)]
struct SpeakConfig {
    #[serde(default = "default_true")]
    enabled: bool,
    #[serde(default = "default_speak_da")]
    read_da: String,
    #[serde(default = "default_speak_en")]
    read_en: String,
    #[serde(default = "default_speak_stop")]
    stop: String,
    #[serde(default = "default_speak_pause")]
    pause: String,
    // 1.0 = normal speed
    #[serde(default = "default_speak_speed")]
    speed: f32,
    #[serde(default = "default_voice_da")]
    voice_da: String,
    #[serde(default = "default_voice_en")]
    voice_en: String,
}

fn default_speak_da() -> String {
    "Ctrl+Alt+D".to_string()
}

fn default_speak_en() -> String {
    "Ctrl+Alt+E".to_string()
}

fn default_speak_stop() -> String {
    "Ctrl+Alt+S".to_string()
}

fn default_speak_pause() -> String {
    "Ctrl+Alt+P".to_string()
}

fn default_speak_speed() -> f32 {
    1.0
}

fn default_voice_da() -> String {
    "da_DK-talesyntese-medium".to_string()
}

fn default_voice_en() -> String {
    "en_US-lessac-medium".to_string()
}

impl Default for SpeakConfig {
    fn default() -> Self {
        SpeakConfig {
            enabled: true,
            read_da: default_speak_da(),
            read_en: default_speak_en(),
            stop: default_speak_stop(),
            pause: default_speak_pause(),
            speed: default_speak_speed(),
            voice_da: default_voice_da(),
            voice_en: default_voice_en(),
        }
    }
}

type SpeakShared = Arc<Mutex<SpeakConfig>>;

// ---------------------------------------------------------------- config

fn config_dir() -> PathBuf {
    let mut p = dirs::config_dir().unwrap_or_else(|| PathBuf::from("."));
    p.push("expander");
    let _ = fs::create_dir_all(&p);
    p
}

fn config_path() -> PathBuf {
    config_dir().join("triggers.json")
}

fn paused_flag_path() -> PathBuf {
    config_dir().join("paused")
}

fn default_entries() -> Vec<Entry> {
    vec![Entry {
        trigger: "omy".into(),
        text: "on my way".into(),
        space: true,
    }]
}

fn load_opt() -> Option<Vec<Entry>> {
    let s = fs::read_to_string(config_path()).ok()?;
    serde_json::from_str(&s).ok()
}

fn load() -> Vec<Entry> {
    load_opt().unwrap_or_else(default_entries)
}

fn save(entries: &[Entry]) {
    if let Ok(json) = serde_json::to_string_pretty(entries) {
        let _ = fs::write(config_path(), json);
    }
}

fn set_enabled(on: bool) {
    let p = paused_flag_path();
    if on {
        let _ = fs::remove_file(p);
    } else {
        let _ = fs::write(p, "paused");
    }
}

fn layout_path() -> PathBuf {
    config_dir().join("layout")
}

fn load_layout() -> String {
    fs::read_to_string(layout_path())
        .map(|s| s.trim().to_lowercase())
        .ok()
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "auto".to_string())
}

fn save_layout(v: &str) {
    let _ = fs::write(layout_path(), v);
}

// Interface language of the settings window
#[derive(Clone, Copy, PartialEq)]
enum Lang {
    En,
    Da,
}

fn tr(lang: Lang, en: &'static str, da: &'static str) -> &'static str {
    match lang {
        Lang::En => en,
        Lang::Da => da,
    }
}

fn lang_path() -> PathBuf {
    config_dir().join("language")
}

fn load_lang() -> Lang {
    let saved = fs::read_to_string(lang_path())
        .map(|s| s.trim().to_lowercase())
        .unwrap_or_default();
    match saved.as_str() {
        "da" => Lang::Da,
        "en" => Lang::En,
        // First run: follow the system language
        _ => {
            if std::env::var("LANG").map_or(false, |l| l.starts_with("da")) {
                Lang::Da
            } else {
                Lang::En
            }
        }
    }
}

fn save_lang(lang: Lang) {
    let _ = fs::write(
        lang_path(),
        match lang {
            Lang::En => "en",
            Lang::Da => "da",
        },
    );
}

fn voice_path() -> PathBuf {
    config_dir().join("voice.json")
}

fn load_voice_opt() -> Option<VoiceConfig> {
    let text = fs::read_to_string(voice_path()).ok()?;
    serde_json::from_str(&text).ok()
}

fn load_voice() -> VoiceConfig {
    load_voice_opt().unwrap_or_default()
}

fn save_voice(cfg: &VoiceConfig) {
    if let Ok(json) = serde_json::to_string_pretty(cfg) {
        let _ = fs::write(voice_path(), json);
    }
}

fn voice_mtime() -> Option<SystemTime> {
    fs::metadata(voice_path()).ok()?.modified().ok()
}

fn speak_path() -> PathBuf {
    config_dir().join("speak.json")
}

fn load_speak_opt() -> Option<SpeakConfig> {
    let text = fs::read_to_string(speak_path()).ok()?;
    serde_json::from_str(&text).ok()
}

fn load_speak() -> SpeakConfig {
    load_speak_opt().unwrap_or_default()
}

fn save_speak(cfg: &SpeakConfig) {
    if let Ok(json) = serde_json::to_string_pretty(cfg) {
        let _ = fs::write(speak_path(), json);
    }
}

fn speak_mtime() -> Option<SystemTime> {
    fs::metadata(speak_path()).ok()?.modified().ok()
}

fn ocr_path() -> PathBuf {
    config_dir().join("ocr.json")
}

fn load_ocr_opt() -> Option<OcrConfig> {
    let text = fs::read_to_string(ocr_path()).ok()?;
    serde_json::from_str(&text).ok()
}

fn load_ocr() -> OcrConfig {
    load_ocr_opt().unwrap_or_default()
}

fn save_ocr(cfg: &OcrConfig) {
    if let Ok(json) = serde_json::to_string_pretty(cfg) {
        let _ = fs::write(ocr_path(), json);
    }
}

fn ocr_mtime() -> Option<SystemTime> {
    fs::metadata(ocr_path()).ok()?.modified().ok()
}

fn mtime() -> Option<SystemTime> {
    fs::metadata(config_path()).ok()?.modified().ok()
}

// ---------------------------------------------------------------- background service

// PID file of the background service (used on Windows and macOS)
#[cfg(not(target_os = "linux"))]
fn pid_path() -> PathBuf {
    config_dir().join("daemon.pid")
}

#[cfg(not(target_os = "linux"))]
fn read_pid() -> Option<u32> {
    fs::read_to_string(pid_path()).ok()?.trim().parse().ok()
}

// ---- Linux: systemd user service, with setsid/pgrep/pkill as fallback

#[cfg(target_os = "linux")]
fn daemon_running() -> bool {
    Command::new("pgrep")
        .args(["-f", "expander --daemon"])
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

#[cfg(target_os = "linux")]
fn systemctl_user(action: &str) -> bool {
    Command::new("systemctl")
        .args(["--user", action, "expander.service"])
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

#[cfg(target_os = "linux")]
fn start_daemon() {
    // Preferred: the systemd user service (stops instantly at shutdown)
    if systemctl_user("start") {
        return;
    }
    let exe = match std::env::current_exe() {
        Ok(e) => e,
        Err(_) => return,
    };
    let mut cmd = Command::new("setsid");
    cmd.arg("--fork").arg(&exe).arg("--daemon").stdin(Stdio::null());
    match fs::File::create(config_dir().join("expander.log")) {
        Ok(f) => {
            if let Ok(f2) = f.try_clone() {
                cmd.stdout(f2);
            }
            cmd.stderr(f);
        }
        Err(_) => {
            cmd.stdout(Stdio::null());
            cmd.stderr(Stdio::null());
        }
    }
    let _ = cmd.spawn();
}

#[cfg(target_os = "linux")]
fn stop_daemon() {
    systemctl_user("stop");
    let _ = Command::new("pkill")
        .args(["-f", "expander --daemon"])
        .status();
}

// ---- Windows: hidden background process tracked by a PID file

#[cfg(windows)]
fn hidden(cmd: &mut Command) -> &mut Command {
    use std::os::windows::process::CommandExt;
    cmd.creation_flags(0x0800_0000) // CREATE_NO_WINDOW
}

#[cfg(windows)]
fn daemon_running() -> bool {
    let pid = match read_pid() {
        Some(p) => p,
        None => return false,
    };
    let mut cmd = Command::new("tasklist");
    cmd.arg("/FI")
        .arg(format!("PID eq {}", pid))
        .arg("/FO")
        .arg("CSV")
        .arg("/NH");
    match hidden(&mut cmd).output() {
        Ok(o) => String::from_utf8_lossy(&o.stdout)
            .to_lowercase()
            .contains("expander.exe"),
        Err(_) => false,
    }
}

#[cfg(windows)]
fn start_daemon() {
    use std::os::windows::process::CommandExt;
    let exe = match std::env::current_exe() {
        Ok(e) => e,
        Err(_) => return,
    };
    let mut cmd = Command::new(exe);
    cmd.arg("--daemon").stdin(Stdio::null());
    match fs::File::create(config_dir().join("expander.log")) {
        Ok(f) => {
            if let Ok(f2) = f.try_clone() {
                cmd.stdout(f2);
            }
            cmd.stderr(f);
        }
        Err(_) => {
            cmd.stdout(Stdio::null());
            cmd.stderr(Stdio::null());
        }
    }
    // DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP: survives closing the settings window
    let _ = cmd.creation_flags(0x0000_0008 | 0x0000_0200).spawn();
}

#[cfg(windows)]
fn stop_daemon() {
    if let Some(pid) = read_pid() {
        let mut cmd = Command::new("taskkill");
        cmd.arg("/PID").arg(pid.to_string()).arg("/F");
        let _ = hidden(&mut cmd).status();
    }
    let _ = fs::remove_file(pid_path());
}

// ---- Other Unix systems (macOS): detached process tracked by a PID file

#[cfg(not(any(target_os = "linux", windows)))]
fn daemon_running() -> bool {
    match read_pid() {
        Some(pid) => Command::new("kill")
            .arg("-0")
            .arg(pid.to_string())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
            .map(|s| s.success())
            .unwrap_or(false),
        None => false,
    }
}

#[cfg(not(any(target_os = "linux", windows)))]
fn start_daemon() {
    let exe = match std::env::current_exe() {
        Ok(e) => e,
        Err(_) => return,
    };
    let mut cmd = Command::new(exe);
    cmd.arg("--daemon").stdin(Stdio::null());
    match fs::File::create(config_dir().join("expander.log")) {
        Ok(f) => {
            if let Ok(f2) = f.try_clone() {
                cmd.stdout(f2);
            }
            cmd.stderr(f);
        }
        Err(_) => {
            cmd.stdout(Stdio::null());
            cmd.stderr(Stdio::null());
        }
    }
    let _ = cmd.spawn();
}

#[cfg(not(any(target_os = "linux", windows)))]
fn stop_daemon() {
    if let Some(pid) = read_pid() {
        let _ = Command::new("kill").arg(pid.to_string()).status();
    }
    let _ = fs::remove_file(pid_path());
}

fn reload_loop(
    entries: Shared,
    enabled: Arc<AtomicBool>,
    layout: LayoutSetting,
    ocr: OcrShared,
    voice: VoiceShared,
    speak: SpeakShared,
) -> ! {
    let mut last = mtime();
    let mut last_ocr = ocr_mtime();
    let mut last_voice = voice_mtime();
    let mut last_speak = speak_mtime();
    loop {
        thread::sleep(Duration::from_millis(1000));
        let now = mtime();
        if now != last {
            last = now;
            if let Some(new_entries) = load_opt() {
                *entries.lock().unwrap() = new_entries;
            }
        }
        let now_ocr = ocr_mtime();
        if now_ocr != last_ocr {
            last_ocr = now_ocr;
            if let Some(new_cfg) = load_ocr_opt() {
                *ocr.lock().unwrap() = new_cfg;
            }
        }
        let now_voice = voice_mtime();
        if now_voice != last_voice {
            last_voice = now_voice;
            if let Some(new_cfg) = load_voice_opt() {
                *voice.lock().unwrap() = new_cfg;
            }
        }
        let now_speak = speak_mtime();
        if now_speak != last_speak {
            last_speak = now_speak;
            if let Some(new_cfg) = load_speak_opt() {
                *speak.lock().unwrap() = new_cfg;
            }
        }
        enabled.store(!paused_flag_path().exists(), Ordering::SeqCst);
        let wanted = load_layout();
        let mut cur = layout.lock().unwrap();
        if *cur != wanted {
            *cur = wanted;
        }
    }
}

fn run_daemon() {
    #[cfg(not(target_os = "linux"))]
    {
        // Another background copy is already running: nothing to do
        if daemon_running() {
            return;
        }
        let _ = fs::write(pid_path(), std::process::id().to_string());
    }

    let entries: Shared = Arc::new(Mutex::new(load()));
    let enabled = Arc::new(AtomicBool::new(!paused_flag_path().exists()));
    let layout: LayoutSetting = Arc::new(Mutex::new(load_layout()));
    let ocr: OcrShared = Arc::new(Mutex::new(load_ocr()));
    let voice: VoiceShared = Arc::new(Mutex::new(load_voice()));
    let speak: SpeakShared = Arc::new(Mutex::new(load_speak()));

    #[cfg(target_os = "linux")]
    control::start(ocr.clone(), voice.clone(), speak.clone());

    // macOS: the key listener has to run on the main thread
    #[cfg(target_os = "macos")]
    {
        let (e, en, l, o, v, sp) = (
            entries.clone(),
            enabled.clone(),
            layout.clone(),
            ocr.clone(),
            voice.clone(),
            speak.clone(),
        );
        thread::spawn(move || reload_loop(e, en, l, o, v, sp));
        input::listen_blocking(entries, enabled, layout, ocr, voice, speak);
    }

    #[cfg(not(target_os = "macos"))]
    {
        input::start_listener(
            entries.clone(),
            enabled.clone(),
            layout.clone(),
            ocr.clone(),
            voice.clone(),
            speak.clone(),
        );
        reload_loop(entries, enabled, layout, ocr, voice, speak);
    }
}

// ---------------------------------------------------------------- input backends

#[cfg(not(target_os = "linux"))]
mod input {
    use super::Shared;
    use enigo::{Direction, Enigo, Key, Keyboard, Settings};
    use rdev::{listen, Event, EventType, Key as RKey};
    use std::{
        sync::{
            atomic::{AtomicBool, Ordering},
            mpsc::{self, Sender},
            Arc,
        },
        thread,
        time::Duration,
    };

    // (characters to erase, replacement text, add a trailing space)
    type Job = (usize, String, bool);

    // Typing worker: erases the trigger and types the replacement
    fn spawn_typer(busy: Arc<AtomicBool>) -> Sender<Job> {
        let (tx, rx) = mpsc::channel::<Job>();
        thread::spawn(move || {
            // On macOS this fails until Accessibility permission is granted: keep retrying
            let mut enigo = loop {
                match Enigo::new(&Settings::default()) {
                    Ok(e) => break e,
                    Err(e) => {
                        eprintln!("Typing backend not ready ({:?}); retrying in 3 seconds", e);
                        thread::sleep(Duration::from_secs(3));
                    }
                }
            };
            for (erase_count, text, trailing_space) in rx {
                busy.store(true, Ordering::SeqCst);
                thread::sleep(Duration::from_millis(30));
                for _ in 0..erase_count {
                    let _ = enigo.key(Key::Backspace, Direction::Click);
                }
                let out = if trailing_space { format!("{} ", text) } else { text };
                let _ = enigo.text(&out);
                thread::sleep(Duration::from_millis(150));
                busy.store(false, Ordering::SeqCst);
            }
        });
        tx
    }

    // The callback that sees every key press
    fn make_callback(
        entries: Shared,
        enabled: Arc<AtomicBool>,
        busy: Arc<AtomicBool>,
        tx: Sender<Job>,
    ) -> impl FnMut(Event) + Send + 'static {
        let mut buffer = String::new();
        let mut cmd_ctrl = 0i32; // macOS: how many of Command/Control are held
        let track = cfg!(target_os = "macos");
        move |event: Event| {
            // On macOS, Command/Control + key is a shortcut, not typing.
            // (On Windows, AltGr is reported as Ctrl+Alt, so this is not used there.)
            match event.event_type {
                EventType::KeyPress(RKey::MetaLeft)
                | EventType::KeyPress(RKey::MetaRight)
                | EventType::KeyPress(RKey::ControlLeft)
                | EventType::KeyPress(RKey::ControlRight)
                    if track =>
                {
                    cmd_ctrl += 1
                }
                EventType::KeyRelease(RKey::MetaLeft)
                | EventType::KeyRelease(RKey::MetaRight)
                | EventType::KeyRelease(RKey::ControlLeft)
                | EventType::KeyRelease(RKey::ControlRight)
                    if track =>
                {
                    cmd_ctrl = (cmd_ctrl - 1).max(0)
                }
                _ => {}
            }

            if busy.load(Ordering::SeqCst) || !enabled.load(Ordering::SeqCst) {
                return;
            }
            if let EventType::KeyPress(key) = event.event_type {
                if cmd_ctrl > 0 {
                    buffer.clear();
                    return;
                }
                match key {
                    RKey::Space => {
                        let word = buffer.to_lowercase();
                        let found = entries
                            .lock()
                            .unwrap()
                            .iter()
                            .find(|e| e.space && e.trigger.to_lowercase() == word)
                            .map(|e| e.text.clone());
                        if let Some(text) = found {
                            let _ = tx.send((word.chars().count() + 1, text, true));
                        }
                        buffer.clear();
                    }
                    RKey::Backspace => {
                        buffer.pop();
                    }
                    RKey::Return | RKey::Tab | RKey::Escape => buffer.clear(),
                    // Modifier keys on their own don't change the typed word.
                    // (AltGr is reported as Ctrl+Alt on Windows, so Ctrl must not clear it.)
                    RKey::ShiftLeft
                    | RKey::ShiftRight
                    | RKey::CapsLock
                    | RKey::Alt
                    | RKey::AltGr
                    | RKey::ControlLeft
                    | RKey::ControlRight
                    | RKey::MetaLeft
                    | RKey::MetaRight => {}
                    _ => match event.name {
                        Some(s) if !s.is_empty() && s.chars().all(|c| !c.is_control()) => {
                            buffer.push_str(&s);
                            if buffer.chars().count() > 32 {
                                buffer.clear();
                            } else {
                                // Instant triggers (no Space needed)
                                let word = buffer.to_lowercase();
                                let found = entries
                                    .lock()
                                    .unwrap()
                                    .iter()
                                    .find(|e| !e.space && e.trigger.to_lowercase() == word)
                                    .map(|e| e.text.clone());
                                if let Some(text) = found {
                                    let _ = tx.send((word.chars().count(), text, false));
                                    buffer.clear();
                                }
                            }
                        }
                        // Arrow keys, Delete, shortcuts, etc.: the word is interrupted
                        _ => buffer.clear(),
                    },
                }
            }
        }
    }

    // Windows: the hook gets its own thread
    #[cfg(windows)]
    pub fn start_listener(
        entries: Shared,
        enabled: Arc<AtomicBool>,
        _layout: super::LayoutSetting,
        _ocr: super::OcrShared,
        _voice: super::VoiceShared,
        _speak: super::SpeakShared,
    ) {
        let busy = Arc::new(AtomicBool::new(false));
        let tx = spawn_typer(busy.clone());
        let callback = make_callback(entries, enabled, busy, tx);
        thread::spawn(move || {
            if let Err(e) = listen(callback) {
                eprintln!("Listener error: {:?}", e);
            }
        });
    }

    // macOS: must run on the main thread. Retries until Input Monitoring is allowed.
    #[cfg(target_os = "macos")]
    pub fn listen_blocking(
        entries: Shared,
        enabled: Arc<AtomicBool>,
        _layout: super::LayoutSetting,
        _ocr: super::OcrShared,
        _voice: super::VoiceShared,
        _speak: super::SpeakShared,
    ) {
        let busy = Arc::new(AtomicBool::new(false));
        let tx = spawn_typer(busy.clone());
        loop {
            let callback = make_callback(entries.clone(), enabled.clone(), busy.clone(), tx.clone());
            if let Err(e) = listen(callback) {
                eprintln!(
                    "Key listener could not start ({:?}). Allow Input Monitoring for Text Expander in System Settings > Privacy & Security.",
                    e
                );
            }
            thread::sleep(Duration::from_secs(3));
        }
    }
}

#[cfg(target_os = "linux")]
mod speak {
    use super::ocr::{gui_cmd, have, notify};
    use super::SpeakConfig;
    use std::{
        fs,
        io::{BufRead, BufReader, Read, Write},
        path::{Path, PathBuf},
        process::{Child, ChildStdin, ChildStdout, Command, Stdio},
        sync::{
            atomic::{AtomicBool, AtomicU32, Ordering},
            mpsc, Mutex,
        },
        thread,
        time::{Duration, Instant},
    };

    // ------------------------------------------------------------ voices

    pub struct Voice {
        pub id: &'static str,
        pub lang: &'static str,
        pub label_en: &'static str,
        pub label_da: &'static str,
        pub path: &'static str,
        pub mb: u32,
    }

    pub const VOICES: &[Voice] = &[
        Voice {
            id: "da_DK-talesyntese-medium",
            lang: "da",
            label_en: "Danish - Talesyntese",
            label_da: "Dansk - Talesyntese",
            path: "da/da_DK/talesyntese/medium",
            mb: 63,
        },
        Voice {
            id: "en_US-lessac-medium",
            lang: "en",
            label_en: "English (US) - Lessac",
            label_da: "Engelsk (US) - Lessac",
            path: "en/en_US/lessac/medium",
            mb: 63,
        },
        Voice {
            id: "en_US-amy-medium",
            lang: "en",
            label_en: "English (US) - Amy",
            label_da: "Engelsk (US) - Amy",
            path: "en/en_US/amy/medium",
            mb: 63,
        },
        Voice {
            id: "en_US-ryan-medium",
            lang: "en",
            label_en: "English (US) - Ryan",
            label_da: "Engelsk (US) - Ryan",
            path: "en/en_US/ryan/medium",
            mb: 63,
        },
        Voice {
            id: "en_GB-alan-medium",
            lang: "en",
            label_en: "English (UK) - Alan",
            label_da: "Engelsk (UK) - Alan",
            path: "en/en_GB/alan/medium",
            mb: 63,
        },
        Voice {
            id: "en_GB-jenny_dioco-medium",
            lang: "en",
            label_en: "English (UK) - Jenny",
            label_da: "Engelsk (UK) - Jenny",
            path: "en/en_GB/jenny_dioco/medium",
            mb: 63,
        },
    ];

    fn data_dir() -> PathBuf {
        let mut p = dirs::data_dir().unwrap_or_else(|| PathBuf::from("."));
        p.push("expander");
        p
    }

    pub fn voices_dir() -> PathBuf {
        data_dir().join("voices")
    }

    fn voice_model(id: &str) -> PathBuf {
        voices_dir().join(format!("{}.onnx", id))
    }

    pub fn voice_ready(id: &str) -> bool {
        voice_model(id).is_file() && voices_dir().join(format!("{}.onnx.json", id)).is_file()
    }

    pub struct VoiceDownload {
        pub id: String,
        pub running: bool,
        pub error: String,
        pub pid: u32,
        pub cancelled: bool,
    }

    static DOWNLOAD: Mutex<Option<VoiceDownload>> = Mutex::new(None);

    // (voice id, still running, error text)
    pub fn download_snapshot() -> Option<(String, bool, String)> {
        DOWNLOAD
            .lock()
            .unwrap()
            .as_ref()
            .map(|d| (d.id.clone(), d.running, d.error.clone()))
    }

    pub fn download_bytes(id: &str) -> u64 {
        fs::metadata(voices_dir().join(format!("{}.onnx.part", id)))
            .map(|m| m.len())
            .unwrap_or(0)
    }

    fn finish_download(id: &str, result: Result<(), String>) {
        let mut st = DOWNLOAD.lock().unwrap();
        *st = Some(VoiceDownload {
            id: id.to_string(),
            running: false,
            error: result.err().unwrap_or_default(),
            pid: 0,
            cancelled: false,
        });
    }

    pub fn start_download(id: &str) {
        let voice = match VOICES.iter().find(|v| v.id == id) {
            Some(v) => v,
            None => return,
        };
        {
            let mut st = DOWNLOAD.lock().unwrap();
            if st.as_ref().map_or(false, |d| d.running) {
                return; // one download at a time
            }
            *st = Some(VoiceDownload {
                id: id.to_string(),
                running: true,
                error: String::new(),
                pid: 0,
                cancelled: false,
            });
        }
        let id = id.to_string();
        let path = voice.path;
        thread::spawn(move || {
            let _ = fs::create_dir_all(voices_dir());
            // the small settings file first, then the voice itself
            for ext in ["onnx.json", "onnx"] {
                let url = format!(
                    "https://huggingface.co/rhasspy/piper-voices/resolve/main/{}/{}.{}",
                    path, id, ext
                );
                let part = voices_dir().join(format!("{}.{}.part", id, ext));
                let done = voices_dir().join(format!("{}.{}", id, ext));
                let spawned = Command::new("curl")
                    .args(["-L", "--fail", "--silent", "--show-error", "-C", "-", "-o"])
                    .arg(&part)
                    .arg(&url)
                    .stdin(Stdio::null())
                    .stdout(Stdio::null())
                    .stderr(Stdio::piped())
                    .spawn();
                let mut child = match spawned {
                    Ok(c) => c,
                    Err(e) => {
                        finish_download(&id, Err(format!("Could not start curl: {}", e)));
                        return;
                    }
                };
                if let Some(st) = DOWNLOAD.lock().unwrap().as_mut() {
                    st.pid = child.id();
                }
                let mut err_text = String::new();
                if let Some(mut stderr) = child.stderr.take() {
                    let _ = stderr.read_to_string(&mut err_text);
                }
                let status = child.wait();
                let cancelled = DOWNLOAD
                    .lock()
                    .unwrap()
                    .as_ref()
                    .map_or(false, |d| d.cancelled);
                match status {
                    Ok(s) if s.success() => {
                        if let Err(e) = fs::rename(&part, &done) {
                            finish_download(&id, Err(e.to_string()));
                            return;
                        }
                    }
                    _ if cancelled => {
                        finish_download(&id, Err(String::new()));
                        return;
                    }
                    _ => {
                        let msg = if err_text.trim().is_empty() {
                            "Download failed.".to_string()
                        } else {
                            err_text.trim().to_string()
                        };
                        finish_download(&id, Err(msg));
                        return;
                    }
                }
            }
            finish_download(&id, Ok(()));
        });
    }

    pub fn cancel_download() {
        let pid = {
            let mut st = DOWNLOAD.lock().unwrap();
            match st.as_mut() {
                Some(d) if d.running => {
                    d.cancelled = true;
                    d.pid
                }
                _ => 0,
            }
        };
        if pid != 0 {
            let _ = Command::new("kill").arg(pid.to_string()).status();
        }
    }

    pub fn delete_voice(id: &str) {
        for ext in ["onnx", "onnx.json", "onnx.part", "onnx.json.part"] {
            let _ = fs::remove_file(voices_dir().join(format!("{}.{}", id, ext)));
        }
    }

    // ------------------------------------------------------------ the voice engine (Piper in a Python helper)

    // Request: one line of JSON. Reply: "OK" or "ERR ..." (the sound is written to a WAV file).
    const TTS_SCRIPT: &str = r#"import json
import sys
import wave

from piper import PiperVoice

try:
    from piper import SynthesisConfig
except Exception:
    SynthesisConfig = None

voices = {}


def load_voice(path):
    if path not in voices:
        voices[path] = PiperVoice.load(path)
    return voices[path]


out = sys.stdout
out.write("READY\n")
out.flush()

for raw in sys.stdin:
    raw = raw.strip()
    if not raw:
        continue
    try:
        request = json.loads(raw)
        voice = load_voice(request["model"])
        scale = float(request.get("length_scale", 1.0))
        with wave.open(request["out"], "wb") as wav:
            if hasattr(voice, "synthesize_wav"):
                if SynthesisConfig is not None:
                    voice.synthesize_wav(request["text"], wav, syn_config=SynthesisConfig(length_scale=scale))
                else:
                    voice.synthesize_wav(request["text"], wav)
            else:
                voice.synthesize(request["text"], wav, length_scale=scale)
        out.write("OK\n")
    except Exception as error:
        out.write("ERR " + " ".join(repr(error).split()) + "\n")
    out.flush()
"#;

    struct Tts {
        child: Child,
        stdin: ChildStdin,
        stdout: BufReader<ChildStdout>,
        last_used: Instant,
    }

    static TTS: Mutex<Option<Tts>> = Mutex::new(None);
    static TTS_STARTING: AtomicBool = AtomicBool::new(false);

    fn python_bin() -> PathBuf {
        data_dir().join("py").join("bin").join("python")
    }

    // Is the "piper" package inside the private Python?
    pub fn piper_installed() -> bool {
        let lib = data_dir().join("py").join("lib");
        match fs::read_dir(lib) {
            Ok(entries) => entries
                .flatten()
                .any(|e| e.path().join("site-packages").join("piper").is_dir()),
            Err(_) => false,
        }
    }

    fn start_tts() -> Result<(), String> {
        if !python_bin().is_file() || !piper_installed() {
            return Err("The reading voice engine (Piper) is not installed. Run the installer again.".to_string());
        }
        fs::create_dir_all(data_dir()).map_err(|e| format!("Could not create the data folder: {}", e))?;
        let script = data_dir().join("tts_server.py");
        fs::write(&script, TTS_SCRIPT).map_err(|e| format!("Could not write the helper: {}", e))?;
        let log = fs::File::create(super::config_dir().join("tts-server.log"))
            .map_err(|e| format!("Could not create the log file: {}", e))?;
        let mut child = Command::new(python_bin())
            .arg("-u")
            .arg(&script)
            .env("PYTHONUNBUFFERED", "1")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::from(log))
            .spawn()
            .map_err(|e| format!("Could not start the reading voice engine: {}", e))?;
        let stdin = child
            .stdin
            .take()
            .ok_or_else(|| "Could not talk to the reading voice engine.".to_string())?;
        let stdout = child
            .stdout
            .take()
            .ok_or_else(|| "Could not read from the reading voice engine.".to_string())?;
        let mut reader = BufReader::new(stdout);
        loop {
            let mut line = String::new();
            let n = reader.read_line(&mut line).unwrap_or(0);
            if n == 0 {
                let _ = child.kill();
                let _ = child.wait();
                return Err("The reading voice engine did not start. See tts-server.log in the settings folder.".to_string());
            }
            if line.trim() == "READY" {
                break;
            }
        }
        *TTS.lock().unwrap() = Some(Tts {
            child,
            stdin,
            stdout: reader,
            last_used: Instant::now(),
        });
        Ok(())
    }

    fn ensure_tts() -> Result<(), String> {
        let began = Instant::now();
        loop {
            if TTS.lock().unwrap().is_some() {
                return Ok(());
            }
            if !TTS_STARTING.swap(true, Ordering::SeqCst) {
                let result = start_tts();
                TTS_STARTING.store(false, Ordering::SeqCst);
                return result;
            }
            if began.elapsed() > Duration::from_secs(120) {
                return Err("The reading voice engine took too long to start.".to_string());
            }
            thread::sleep(Duration::from_millis(100));
        }
    }

    // Frees the memory when nothing was read for ten minutes
    pub fn start_idle_watch() {
        thread::spawn(|| loop {
            thread::sleep(Duration::from_secs(30));
            let mut guard = TTS.lock().unwrap();
            let idle = guard
                .as_ref()
                .map_or(false, |t| t.last_used.elapsed() > Duration::from_secs(600));
            if idle && GENERATION_ACTIVE.load(Ordering::SeqCst) == 0 {
                if let Some(mut t) = guard.take() {
                    let _ = t.child.kill();
                    let _ = t.child.wait();
                }
            }
        });
    }

    // Turns one piece of text into a WAV file
    fn synth_request(model: &Path, text: &str, out: &Path, length_scale: f32) -> Result<(), String> {
        ensure_tts()?;
        let request = serde_json::json!({
            "model": model.to_string_lossy(),
            "text": text,
            "out": out.to_string_lossy(),
            "length_scale": length_scale,
        })
        .to_string();
        let mut guard = TTS.lock().unwrap();
        let reply: Option<String> = match guard.as_mut() {
            Some(t) => {
                let outcome: std::io::Result<String> = (|| -> std::io::Result<String> {
                    t.stdin.write_all(request.as_bytes())?;
                    t.stdin.write_all(b"\n")?;
                    t.stdin.flush()?;
                    let mut line = String::new();
                    t.stdout.read_line(&mut line)?;
                    Ok(line)
                })();
                match outcome {
                    Ok(line) if !line.is_empty() => {
                        t.last_used = Instant::now();
                        Some(line)
                    }
                    _ => None,
                }
            }
            None => None,
        };
        match reply {
            Some(line) => {
                let t = line.trim();
                if t == "OK" {
                    Ok(())
                } else {
                    Err(format!("The reading voice engine reported: {}", t.trim_start_matches("ERR ")))
                }
            }
            None => {
                if let Some(mut dead) = guard.take() {
                    let _ = dead.child.kill();
                    let _ = dead.child.wait();
                }
                Err("The reading voice engine stopped. Try again.".to_string())
            }
        }
    }

    // ------------------------------------------------------------ getting the selected text

    fn gvariant_quote(s: &str) -> String {
        let mut out = String::from("'");
        for c in s.chars() {
            match c {
                '\\' => out.push_str("\\\\"),
                '\'' => out.push_str("\\'"),
                '\n' => out.push_str("\\n"),
                '\r' => {}
                _ => out.push(c),
            }
        }
        out.push('\'');
        out
    }

    // ('some text',)  ->  some text
    fn parse_gvariant_string(output: &str) -> Option<String> {
        let t = output.trim();
        let t = t.strip_prefix('(')?;
        let t = t.strip_suffix(",)")?;
        let quote = t.chars().next()?;
        if (quote != '\'' && quote != '"') || t.len() < 2 || !t.ends_with(quote) {
            return None;
        }
        let inner = &t[1..t.len() - 1];
        let mut result = String::new();
        let mut chars = inner.chars();
        while let Some(c) = chars.next() {
            if c == '\\' {
                match chars.next() {
                    Some('n') => result.push('\n'),
                    Some('t') => result.push('\t'),
                    Some('r') => result.push('\r'),
                    Some('\\') => result.push('\\'),
                    Some('\'') => result.push('\''),
                    Some('"') => result.push('"'),
                    Some(other) => {
                        result.push('\\');
                        result.push(other);
                    }
                    None => result.push('\\'),
                }
            } else {
                result.push(c);
            }
        }
        Some(result)
    }

    fn klipper_call(method: &str, arg: Option<String>) -> Option<String> {
        let mut cmd = gui_cmd("gdbus");
        cmd.args([
            "call",
            "--session",
            "--dest",
            "org.kde.klipper",
            "--object-path",
            "/klipper",
            "--method",
        ])
        .arg(format!("org.kde.klipper.klipper.{}", method));
        if let Some(a) = arg {
            cmd.arg(a);
        }
        let output = cmd
            .stdin(Stdio::null())
            .stderr(Stdio::null())
            .output()
            .ok()?;
        if output.status.success() {
            Some(String::from_utf8_lossy(&output.stdout).to_string())
        } else {
            None
        }
    }

    fn klipper_get() -> Option<String> {
        klipper_call("getClipboardContents", None).and_then(|o| parse_gvariant_string(&o))
    }

    fn klipper_set(text: &str) {
        let _ = klipper_call("setClipboardContents", Some(gvariant_quote(text)));
    }

    fn klipper_clear() {
        let _ = klipper_call("clearClipboardContents", None);
    }

    fn read_clipboard_other() -> Option<String> {
        if have("wl-paste") {
            if let Ok(o) = gui_cmd("wl-paste")
                .arg("--no-newline")
                .stdin(Stdio::null())
                .stderr(Stdio::null())
                .output()
            {
                if o.status.success() {
                    return Some(String::from_utf8_lossy(&o.stdout).to_string());
                }
            }
        }
        if have("xclip") {
            if let Ok(o) = gui_cmd("xclip")
                .args(["-o", "-selection", "clipboard"])
                .stdin(Stdio::null())
                .stderr(Stdio::null())
                .output()
            {
                if o.status.success() {
                    return Some(String::from_utf8_lossy(&o.stdout).to_string());
                }
            }
        }
        None
    }

    // Copies the text that is selected in the program in front (the same as pressing Ctrl+C)
    fn grab_selection() -> Result<String, String> {
        if klipper_get().is_some() {
            // KDE: clear the clipboard first, so that "nothing selected" can be told from "the same text"
            let old = klipper_get().unwrap_or_default();
            klipper_clear();
            if !super::input::press_copy() {
                return Err("The typing keyboard is not ready, so the text could not be copied.".to_string());
            }
            let began = Instant::now();
            let mut text = String::new();
            while began.elapsed() < Duration::from_millis(1500) {
                thread::sleep(Duration::from_millis(80));
                text = klipper_get().unwrap_or_default();
                if !text.trim().is_empty() {
                    break;
                }
            }
            if text.trim().is_empty() {
                if !old.is_empty() {
                    klipper_set(&old);
                }
                return Err("No text is selected (or the program did not copy it).".to_string());
            }
            Ok(text)
        } else {
            if !super::input::press_copy() {
                return Err("The typing keyboard is not ready, so the text could not be copied.".to_string());
            }
            thread::sleep(Duration::from_millis(350));
            match read_clipboard_other() {
                Some(t) if !t.trim().is_empty() => Ok(t),
                _ => Err("No text could be copied. On KDE this needs Klipper; elsewhere wl-clipboard or xclip.".to_string()),
            }
        }
    }

    // ------------------------------------------------------------ reading it out loud

    static GENERATION: AtomicU32 = AtomicU32::new(0);
    static GENERATION_ACTIVE: AtomicU32 = AtomicU32::new(0);
    static PLAYER_PID: AtomicU32 = AtomicU32::new(0);
    static PAUSED: AtomicBool = AtomicBool::new(false);

    fn signal(pid: u32, name: &str) {
        if pid != 0 {
            let _ = Command::new("kill")
                .arg(format!("-{}", name))
                .arg(pid.to_string())
                .status();
        }
    }

    fn kill_player() {
        let pid = PLAYER_PID.load(Ordering::SeqCst);
        signal(pid, "KILL");
    }

    // Plays one WAV file and waits until it is finished (or stopped)
    fn play_file(path: &Path) {
        let file = path.to_string_lossy().to_string();
        for (tool, args) in [
            ("paplay", Vec::<&str>::new()),
            ("pw-play", Vec::<&str>::new()),
            ("pw-cat", vec!["--playback"]),
            ("aplay", vec!["-q"]),
        ] {
            if !have(tool) {
                continue;
            }
            let spawned = gui_cmd(tool)
                .args(&args)
                .arg(&file)
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .spawn();
            if let Ok(mut child) = spawned {
                PLAYER_PID.store(child.id(), Ordering::SeqCst);
                let status = child.wait();
                PLAYER_PID.store(0, Ordering::SeqCst);
                if status.map(|s| s.success()).unwrap_or(false) {
                    return;
                }
                // stopped on purpose, or this player failed: do not start another one then
                return;
            }
        }
    }

    // Cuts a text into pieces at the ends of sentences
    fn split_text(text: &str, max: usize) -> Vec<String> {
        let mut sentences: Vec<String> = Vec::new();
        let mut current = String::new();
        for c in text.replace('\r', "").chars() {
            current.push(c);
            if c == '.' || c == '!' || c == '?' || c == '\n' {
                let t = current.trim().to_string();
                if !t.is_empty() {
                    sentences.push(t);
                }
                current.clear();
            }
        }
        let rest = current.trim().to_string();
        if !rest.is_empty() {
            sentences.push(rest);
        }

        let mut chunks: Vec<String> = Vec::new();
        let mut acc = String::new();
        for sentence in sentences {
            // a very long sentence is cut at spaces
            let mut parts: Vec<String> = Vec::new();
            if sentence.chars().count() > max {
                let mut piece = String::new();
                for word in sentence.split_whitespace() {
                    if !piece.is_empty() && piece.chars().count() + word.chars().count() + 1 > max {
                        parts.push(piece.clone());
                        piece.clear();
                    }
                    if !piece.is_empty() {
                        piece.push(' ');
                    }
                    piece.push_str(word);
                }
                if !piece.is_empty() {
                    parts.push(piece);
                }
            } else {
                parts.push(sentence);
            }
            for p in parts {
                if !acc.is_empty() && acc.chars().count() + p.chars().count() + 1 > max {
                    chunks.push(acc.clone());
                    acc.clear();
                }
                if !acc.is_empty() {
                    acc.push(' ');
                }
                acc.push_str(&p);
            }
        }
        if !acc.is_empty() {
            chunks.push(acc);
        }
        chunks
    }

    // The next piece is prepared while the current one is playing
    fn read_text(text: &str, voice_id: &str, speed: f32, generation: u32) {
        let chunks = split_text(text, 280);
        if chunks.is_empty() {
            return;
        }
        GENERATION_ACTIVE.fetch_add(1, Ordering::SeqCst);
        let model = voice_model(voice_id);
        let length_scale = 1.0 / speed.clamp(0.5, 2.0);
        let (tx, rx) = mpsc::sync_channel::<PathBuf>(2);
        let synth = thread::spawn(move || {
            for (i, chunk) in chunks.iter().enumerate() {
                if GENERATION.load(Ordering::SeqCst) != generation {
                    break;
                }
                let out = std::env::temp_dir().join(format!(
                    "expander-tts-{}-{}-{}.wav",
                    std::process::id(),
                    generation,
                    i
                ));
                match synth_request(&model, chunk, &out, length_scale) {
                    Ok(()) => {
                        if tx.send(out).is_err() {
                            break;
                        }
                    }
                    Err(e) => {
                        notify("Read aloud failed", &e);
                        break;
                    }
                }
            }
        });
        for path in rx {
            // while paused, wait here between two pieces
            while PAUSED.load(Ordering::SeqCst) && GENERATION.load(Ordering::SeqCst) == generation {
                thread::sleep(Duration::from_millis(60));
            }
            if GENERATION.load(Ordering::SeqCst) == generation {
                play_file(&path);
            }
            let _ = fs::remove_file(&path);
        }
        let _ = synth.join();
        GENERATION_ACTIVE.fetch_sub(1, Ordering::SeqCst);
    }

    pub fn stop() {
        GENERATION.fetch_add(1, Ordering::SeqCst);
        PAUSED.store(false, Ordering::SeqCst);
        kill_player();
    }

    pub fn toggle_pause() {
        let now_paused = !PAUSED.load(Ordering::SeqCst);
        PAUSED.store(now_paused, Ordering::SeqCst);
        let pid = PLAYER_PID.load(Ordering::SeqCst);
        signal(pid, if now_paused { "STOP" } else { "CONT" });
    }

    // Selected text -> spoken
    fn read_selection(cfg: SpeakConfig, lang: &str) {
        let generation = GENERATION.fetch_add(1, Ordering::SeqCst) + 1;
        PAUSED.store(false, Ordering::SeqCst);
        kill_player();
        let voice_id = if lang == "da" {
            cfg.voice_da.clone()
        } else {
            cfg.voice_en.clone()
        };
        if !voice_ready(&voice_id) {
            notify(
                "Read aloud",
                "Download a voice first: open Text Expander > Read aloud.",
            );
            return;
        }
        let text = match grab_selection() {
            Ok(t) => t,
            Err(e) => {
                notify("Read aloud", &e);
                return;
            }
        };
        if GENERATION.load(Ordering::SeqCst) != generation {
            return; // stopped or replaced meanwhile
        }
        read_text(&text, &voice_id, cfg.speed, generation);
    }

    pub fn run_action(action: &str, cfg: SpeakConfig) {
        match action {
            "read-da" => read_selection(cfg, "da"),
            "read-en" => read_selection(cfg, "en"),
            "read-stop" => stop(),
            "read-pause" => toggle_pause(),
            _ => {}
        }
    }

    // The "Test" buttons in the window
    pub fn say_test(cfg: SpeakConfig, lang: &str) -> Result<(), String> {
        let voice_id = if lang == "da" {
            cfg.voice_da.clone()
        } else {
            cfg.voice_en.clone()
        };
        if !voice_ready(&voice_id) {
            return Err("Download this voice first.".to_string());
        }
        let sample = if lang == "da" {
            "Hej! Det her er en test af oplæsningen."
        } else {
            "Hello! This is a test of the reading voice."
        };
        let generation = GENERATION.fetch_add(1, Ordering::SeqCst) + 1;
        PAUSED.store(false, Ordering::SeqCst);
        kill_player();
        read_text(sample, &voice_id, cfg.speed, generation);
        Ok(())
    }

    pub fn requirements() -> Vec<(String, bool)> {
        vec![
            (
                "Reading voice engine (Piper in Python, set up by the installer)".to_string(),
                piper_installed(),
            ),
            (
                "Sound player (paplay, pw-play or aplay)".to_string(),
                have("paplay") || have("pw-play") || have("pw-cat") || have("aplay"),
            ),
            (
                "KDE clipboard (gdbus + Klipper) to copy the selected text".to_string(),
                have("gdbus"),
            ),
        ]
    }
}

#[cfg(target_os = "linux")]
mod control {
    use super::{OcrShared, SpeakShared, VoiceShared};
    use std::{
        io::{Read, Write},
        os::unix::net::{UnixListener, UnixStream},
        path::PathBuf,
        thread,
    };

    pub fn socket_path() -> PathBuf {
        dirs::runtime_dir()
            .unwrap_or_else(super::config_dir)
            .join("expander.sock")
    }

    // The background service listens for commands such as "voice-toggle"
    pub fn start(ocr: OcrShared, voice: VoiceShared, speak: SpeakShared) {
        let path = socket_path();
        let _ = std::fs::remove_file(&path);
        let listener = match UnixListener::bind(&path) {
            Ok(l) => l,
            Err(e) => {
                eprintln!("Could not open the command socket: {}", e);
                return;
            }
        };
        thread::spawn(move || {
            for stream in listener.incoming() {
                let mut stream = match stream {
                    Ok(s) => s,
                    Err(_) => continue,
                };
                let mut text = String::new();
                let _ = stream.read_to_string(&mut text);
                let command = text.trim().to_string();
                let v = voice.lock().unwrap().clone();
                let o = ocr.lock().unwrap().clone();
                let sp = speak.lock().unwrap().clone();
                match command.as_str() {
                    "voice-toggle" => {
                        thread::spawn(move || super::voice::toggle(v));
                    }
                    "voice-start" => {
                        thread::spawn(move || super::voice::start(&v));
                    }
                    "voice-stop" => {
                        thread::spawn(move || super::voice::stop_if_recording(v));
                    }
                    "ocr" => {
                        thread::spawn(move || super::ocr::run_with_notification(o));
                    }
                    "read-da" | "read-en" | "read-stop" | "read-pause" => {
                        let action = command.clone();
                        thread::spawn(move || super::speak::run_action(&action, sp));
                    }
                    _ => {}
                }
                let _ = stream.write_all(b"ok\n");
            }
        });
    }

    // expander --voice-toggle  (and --voice-start, --voice-stop, --ocr) sends the command here
    pub fn send(command: &str) -> bool {
        match UnixStream::connect(socket_path()) {
            Ok(mut s) => {
                let _ = s.write_all(command.as_bytes());
                let _ = s.shutdown(std::net::Shutdown::Write);
                let mut reply = String::new();
                let _ = s.read_to_string(&mut reply);
                true
            }
            Err(_) => false,
        }
    }
}

#[cfg(target_os = "linux")]
mod ocr {
    use super::OcrConfig;
    use std::{
        io::Write,
        path::PathBuf,
        process::{Command, Stdio},
        sync::atomic::{AtomicBool, Ordering},
    };

    static RUNNING: AtomicBool = AtomicBool::new(false);

    pub fn have(program: &str) -> bool {
        match std::env::var_os("PATH") {
            Some(paths) => std::env::split_paths(&paths).any(|dir| dir.join(program).is_file()),
            None => false,
        }
    }

    // A command that can reach the screen and clipboard even when it is started
    // from the background service (which may not have the desktop's variables).
    pub fn gui_cmd(program: &str) -> Command {
        let mut cmd = Command::new(program);
        if let Some(dir) = std::env::var_os("XDG_RUNTIME_DIR") {
            let dir = PathBuf::from(dir);
            if std::env::var_os("WAYLAND_DISPLAY").is_none() {
                if let Ok(entries) = std::fs::read_dir(&dir) {
                    for e in entries.flatten() {
                        let name = e.file_name().to_string_lossy().to_string();
                        if name.starts_with("wayland-") && !name.ends_with(".lock") {
                            cmd.env("WAYLAND_DISPLAY", &name);
                            break;
                        }
                    }
                }
            }
            if std::env::var_os("XAUTHORITY").is_none() {
                if let Ok(entries) = std::fs::read_dir(&dir) {
                    for e in entries.flatten() {
                        let name = e.file_name().to_string_lossy().to_string();
                        if name.starts_with("xauth_") {
                            cmd.env("XAUTHORITY", e.path());
                            break;
                        }
                    }
                }
            }
        }
        if std::env::var_os("DISPLAY").is_none() {
            let mut display = String::from(":0");
            if let Ok(entries) = std::fs::read_dir("/tmp/.X11-unix") {
                let mut names: Vec<String> = entries
                    .flatten()
                    .map(|e| e.file_name().to_string_lossy().to_string())
                    .filter(|n| n.starts_with('X'))
                    .collect();
                names.sort();
                if let Some(first) = names.first() {
                    display = format!(":{}", &first[1..]);
                }
            }
            cmd.env("DISPLAY", display);
        }
        cmd
    }

    pub fn notify(title: &str, body: &str) {
        let _ = gui_cmd("notify-send")
            .args(["-a", "Text Expander", "-t", "5000", title, body])
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status();
    }

    pub fn installed_languages() -> Vec<String> {
        match Command::new("tesseract").arg("--list-langs").output() {
            Ok(o) => {
                let mut text = String::from_utf8_lossy(&o.stdout).to_string();
                text.push('\n');
                text.push_str(&String::from_utf8_lossy(&o.stderr));
                text.lines()
                    .map(|l| l.trim().to_string())
                    .filter(|l| !l.is_empty() && !l.starts_with("List of"))
                    .collect()
            }
            Err(_) => Vec::new(),
        }
    }

    pub fn requirements() -> Vec<(String, bool)> {
        vec![
            ("Tesseract (reads the text)".to_string(), have("tesseract")),
            (
                "Screenshot tool (spectacle, gnome-screenshot, grim + slurp, or maim)".to_string(),
                have("spectacle")
                    || have("gnome-screenshot")
                    || (have("grim") && have("slurp"))
                    || have("maim"),
            ),
            (
                "Clipboard tool (KDE Klipper via gdbus, wl-copy, xclip or xsel)".to_string(),
                have("gdbus") || have("wl-copy") || have("xclip") || have("xsel"),
            ),
        ]
    }

    // Let the user pick an area; the picture is saved to `path`.
    // Ok(true): picture taken. Ok(false): the user cancelled.
    fn capture(path: &str) -> Result<bool, String> {
        let _ = std::fs::remove_file(path);
        if have("spectacle") {
            let _ = gui_cmd("spectacle")
                .args(["--background", "--nonotify", "--region", "--output", path])
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status();
        } else if have("gnome-screenshot") {
            let _ = gui_cmd("gnome-screenshot")
                .args(["-a", "-f", path])
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status();
        } else if have("grim") && have("slurp") {
            let area = gui_cmd("slurp").output().map_err(|e| format!("slurp failed: {}", e))?;
            if !area.status.success() {
                return Ok(false);
            }
            let geometry = String::from_utf8_lossy(&area.stdout).trim().to_string();
            let _ = gui_cmd("grim")
                .arg("-g")
                .arg(&geometry)
                .arg(path)
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status();
        } else if have("maim") {
            let _ = gui_cmd("maim")
                .args(["-s", path])
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status();
        } else {
            return Err("No screenshot tool found. Install spectacle (KDE), gnome-screenshot, grim + slurp, or maim.".to_string());
        }
        Ok(std::fs::metadata(path).map(|m| m.len() > 0).unwrap_or(false))
    }

    // Bigger, grayscale pictures are read more accurately (needs ImageMagick; optional)
    fn enlarge(src: &str, dst: &str) -> bool {
        let tool = if have("magick") {
            "magick"
        } else if have("convert") {
            "convert"
        } else {
            return false;
        };
        Command::new(tool)
            .args([src, "-colorspace", "Gray", "-resize", "200%", dst])
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
            .map(|s| s.success())
            .unwrap_or(false)
    }

    fn recognize(img: &str, languages: &str) -> Result<String, String> {
        if !have("tesseract") {
            return Err("Tesseract is not installed. Fedora: sudo dnf install tesseract tesseract-langpack-dan".to_string());
        }
        let installed = installed_languages();
        let wanted: Vec<&str> = languages
            .split('+')
            .map(|l| l.trim())
            .filter(|l| !l.is_empty() && installed.iter().any(|i| i == l))
            .collect();
        let lang_arg = if wanted.is_empty() {
            match installed.iter().find(|l| l.as_str() != "osd") {
                Some(l) => l.clone(),
                None => return Err("Tesseract has no language data installed.".to_string()),
            }
        } else {
            wanted.join("+")
        };
        let out = Command::new("tesseract")
            .arg(img)
            .arg("stdout")
            .arg("-l")
            .arg(&lang_arg)
            .output()
            .map_err(|e| format!("Could not run tesseract: {}", e))?;
        if !out.status.success() {
            return Err(format!(
                "Tesseract failed: {}",
                String::from_utf8_lossy(&out.stderr).trim()
            ));
        }
        Ok(String::from_utf8_lossy(&out.stdout)
            .replace('\u{c}', "")
            .trim()
            .to_string())
    }

    fn pipe_to(program: &str, args: &[&str], text: &str) -> bool {
        let mut child = match gui_cmd(program)
            .args(args)
            .stdin(Stdio::piped())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn()
        {
            Ok(c) => c,
            Err(_) => return false,
        };
        if let Some(mut stdin) = child.stdin.take() {
            if stdin.write_all(text.as_bytes()).is_err() {
                return false;
            }
        }
        child.wait().map(|s| s.success()).unwrap_or(false)
    }

    // Text as a GVariant string literal (for gdbus)
    fn gvariant_quote(s: &str) -> String {
        let mut out = String::from("'");
        for c in s.chars() {
            match c {
                '\\' => out.push_str("\\\\"),
                '\'' => out.push_str("\\'"),
                '\n' => out.push_str("\\n"),
                '\r' => {}
                _ => out.push(c),
            }
        }
        out.push('\'');
        out
    }

    fn copy_to_clipboard(text: &str) -> bool {
        // KDE: ask Klipper (works on Wayland and X11)
        if have("gdbus") {
            let ok = gui_cmd("gdbus")
                .args([
                    "call",
                    "--session",
                    "--dest",
                    "org.kde.klipper",
                    "--object-path",
                    "/klipper",
                    "--method",
                    "org.kde.klipper.klipper.setClipboardContents",
                ])
                .arg(gvariant_quote(text))
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status()
                .map(|s| s.success())
                .unwrap_or(false);
            if ok {
                return true;
            }
        }
        if have("wl-copy") && pipe_to("wl-copy", &[], text) {
            return true;
        }
        if have("xclip") && pipe_to("xclip", &["-selection", "clipboard"], text) {
            return true;
        }
        if have("xsel") && pipe_to("xsel", &["--clipboard", "--input"], text) {
            return true;
        }
        false
    }

    // Select area -> read text -> copy to clipboard.
    // Err("") means the user cancelled the selection.
    pub fn run_once(cfg: OcrConfig) -> Result<String, String> {
        if RUNNING.swap(true, Ordering::SeqCst) {
            return Err("OCR is already running.".to_string());
        }
        let result = run_inner(&cfg);
        RUNNING.store(false, Ordering::SeqCst);
        result
    }

    fn run_inner(cfg: &OcrConfig) -> Result<String, String> {
        let dir = std::env::temp_dir();
        let pid = std::process::id();
        let shot = dir
            .join(format!("expander-ocr-{}.png", pid))
            .to_string_lossy()
            .to_string();
        let big = dir
            .join(format!("expander-ocr-{}-big.png", pid))
            .to_string_lossy()
            .to_string();

        if !capture(&shot)? {
            return Err(String::new());
        }
        let image = if enlarge(&shot, &big) { big.clone() } else { shot.clone() };
        let text = recognize(&image, &cfg.languages);
        let _ = std::fs::remove_file(&shot);
        let _ = std::fs::remove_file(&big);
        let text = text?;
        if text.is_empty() {
            return Err("No text found in the selected area.".to_string());
        }
        if !copy_to_clipboard(&text) {
            return Err("Could not copy to the clipboard (needs KDE Klipper, wl-clipboard or xclip).".to_string());
        }
        Ok(text)
    }

    // Used by the keyboard shortcut: result shown as a desktop notification
    pub fn run_with_notification(cfg: OcrConfig) {
        match run_once(cfg) {
            Ok(text) => {
                let preview: String = text.chars().take(80).collect();
                notify(
                    "Text copied",
                    &format!("{} characters copied: {}", text.chars().count(), preview),
                );
            }
            Err(e) if e.is_empty() => {}
            Err(e) => notify("OCR failed", &e),
        }
    }
}

#[cfg(target_os = "linux")]
mod voice {
    use super::ocr::{gui_cmd, have, notify};
    use super::VoiceConfig;
    use std::{
        collections::VecDeque,
        fs,
        io::{BufRead, BufReader, Read, Write},
        path::{Path, PathBuf},
        process::{Child, ChildStdin, ChildStdout, Command, Stdio},
        sync::{
            atomic::{AtomicBool, Ordering},
            Arc, Mutex,
        },
        thread::{self, JoinHandle},
        time::{Duration, Instant},
    };

    // ------------------------------------------------------------ models

    #[derive(Clone, Copy, PartialEq)]
    pub enum Engine {
        Whisper,
        Parakeet,
        // Parakeet in a Python helper that keeps the model loaded in memory (fast)
        ParakeetOnnx,
    }

    pub struct Model {
        pub id: &'static str,
        pub label_en: &'static str,
        pub label_da: &'static str,
        pub file: &'static str,
        pub repo: &'static str,
        pub engine: Engine,
        pub mb: u32,
    }

    pub const MODELS: &[Model] = &[
        Model {
            id: "parakeet-onnx",
            label_en: "Parakeet - fastest, stays loaded in memory (recommended)",
            label_da: "Parakeet - hurtigst, bliver i hukommelsen (anbefalet)",
            file: "",
            repo: "",
            engine: Engine::ParakeetOnnx,
            mb: 670,
        },
        Model {
            id: "parakeet-q8_0",
            label_en: "Parakeet - fast, Danish and English (recommended)",
            label_da: "Parakeet - hurtig, dansk og engelsk (anbefalet)",
            file: "ggml-parakeet-tdt-0.6b-v3-q8_0.bin",
            repo: "ggml-org/parakeet-GGUF",
            engine: Engine::Parakeet,
            mb: 669,
        },
        Model {
            id: "parakeet-q4_k",
            label_en: "Parakeet, compressed - fast, a bit smaller",
            label_da: "Parakeet, komprimeret - hurtig, lidt mindre",
            file: "ggml-parakeet-tdt-0.6b-v3-q4_k.bin",
            repo: "ggml-org/parakeet-GGUF",
            engine: Engine::Parakeet,
            mb: 416,
        },
        Model {
            id: "parakeet-q4_0",
            label_en: "Parakeet, smallest - for weaker computers",
            label_da: "Parakeet, mindst - til svagere computere",
            file: "ggml-parakeet-tdt-0.6b-v3-q4_0.bin",
            repo: "ggml-org/parakeet-GGUF",
            engine: Engine::Parakeet,
            mb: 356,
        },
        Model {
            id: "tiny-q5_1",
            label_en: "Whisper Tiny - fastest Whisper, weak at Danish",
            label_da: "Whisper Tiny - hurtigst, svag til dansk",
            file: "ggml-tiny-q5_1.bin",
            repo: "ggerganov/whisper.cpp",
            engine: Engine::Whisper,
            mb: 31,
        },
        Model {
            id: "base-q5_1",
            label_en: "Whisper Base - very fast, so-so Danish",
            label_da: "Whisper Base - meget hurtig, middel dansk",
            file: "ggml-base-q5_1.bin",
            repo: "ggerganov/whisper.cpp",
            engine: Engine::Whisper,
            mb: 57,
        },
        Model {
            id: "small-q5_1",
            label_en: "Whisper Small - fast, fair Danish",
            label_da: "Whisper Small - hurtig, nogenlunde dansk",
            file: "ggml-small-q5_1.bin",
            repo: "ggerganov/whisper.cpp",
            engine: Engine::Whisper,
            mb: 181,
        },
        Model {
            id: "medium-q5_0",
            label_en: "Whisper Medium - good Danish, slow",
            label_da: "Whisper Medium - godt dansk, langsom",
            file: "ggml-medium-q5_0.bin",
            repo: "ggerganov/whisper.cpp",
            engine: Engine::Whisper,
            mb: 514,
        },
        Model {
            id: "large-v3-turbo-q5_0",
            label_en: "Whisper Large v3 Turbo, compressed - very good, slow",
            label_da: "Whisper Large v3 Turbo, komprimeret - meget god, langsom",
            file: "ggml-large-v3-turbo-q5_0.bin",
            repo: "ggerganov/whisper.cpp",
            engine: Engine::Whisper,
            mb: 547,
        },
        Model {
            id: "large-v3-turbo",
            label_en: "Whisper Large v3 Turbo - very good, needs more memory",
            label_da: "Whisper Large v3 Turbo - meget god, bruger mere hukommelse",
            file: "ggml-large-v3-turbo.bin",
            repo: "ggerganov/whisper.cpp",
            engine: Engine::Whisper,
            mb: 1624,
        },
        Model {
            id: "large-v3-q5_0",
            label_en: "Whisper Large v3, compressed - best quality, very slow",
            label_da: "Whisper Large v3, komprimeret - bedste kvalitet, meget langsom",
            file: "ggml-large-v3-q5_0.bin",
            repo: "ggerganov/whisper.cpp",
            engine: Engine::Whisper,
            mb: 1080,
        },
        Model {
            id: "large-v3",
            label_en: "Whisper Large v3 - best quality, slowest",
            label_da: "Whisper Large v3 - bedste kvalitet, langsomst",
            file: "ggml-large-v3.bin",
            repo: "ggerganov/whisper.cpp",
            engine: Engine::Whisper,
            mb: 3100,
        },
    ];

    fn data_dir() -> PathBuf {
        let mut p = dirs::data_dir().unwrap_or_else(|| PathBuf::from("."));
        p.push("expander");
        p
    }

    pub fn models_dir() -> PathBuf {
        data_dir().join("models")
    }

    fn live_path() -> PathBuf {
        super::config_dir().join("voice_live.txt")
    }

    pub fn model_file(id: &str) -> Option<PathBuf> {
        MODELS
            .iter()
            .find(|m| m.id == id)
            .map(|m| models_dir().join(m.file))
    }

    pub fn model_engine(id: &str) -> Option<Engine> {
        MODELS.iter().find(|m| m.id == id).map(|m| m.engine)
    }

    // A model is only renamed to its final name when the download completed
    pub fn model_ready(id: &str) -> bool {
        match model_engine(id) {
            Some(Engine::ParakeetOnnx) => onnx_marker().is_file() && python_bin().is_file(),
            Some(_) => model_file(id).map(|p| p.is_file()).unwrap_or(false),
            None => false,
        }
    }

    pub struct DownloadState {
        pub id: String,
        pub running: bool,
        pub error: String,
        pub pid: u32,
        pub cancelled: bool,
    }

    static DOWNLOAD: Mutex<Option<DownloadState>> = Mutex::new(None);

    // (model id, still running, error text)
    pub fn download_snapshot() -> Option<(String, bool, String)> {
        DOWNLOAD
            .lock()
            .unwrap()
            .as_ref()
            .map(|d| (d.id.clone(), d.running, d.error.clone()))
    }

    pub fn download_bytes(id: &str) -> u64 {
        if model_engine(id) == Some(Engine::ParakeetOnnx) {
            return dir_size(&onnx_cache_dir());
        }
        match MODELS.iter().find(|m| m.id == id) {
            Some(m) => fs::metadata(models_dir().join(format!("{}.part", m.file)))
                .map(|md| md.len())
                .unwrap_or(0),
            None => 0,
        }
    }

    fn finish_download(id: &str, result: Result<(), String>) {
        let mut st = DOWNLOAD.lock().unwrap();
        *st = Some(DownloadState {
            id: id.to_string(),
            running: false,
            error: result.err().unwrap_or_default(),
            pid: 0,
            cancelled: false,
        });
    }

    pub fn start_download(id: &str) {
        let model = match MODELS.iter().find(|m| m.id == id) {
            Some(m) => m,
            None => return,
        };
        {
            let mut st = DOWNLOAD.lock().unwrap();
            if st.as_ref().map_or(false, |d| d.running) {
                return; // one download at a time
            }
            *st = Some(DownloadState {
                id: id.to_string(),
                running: true,
                error: String::new(),
                pid: 0,
                cancelled: false,
            });
        }
        if model.engine == Engine::ParakeetOnnx {
            // The helper downloads the model itself the first time it starts
            let onnx_id = id.to_string();
            thread::spawn(move || {
                let result = ensure_server();
                let cancelled = DOWNLOAD
                    .lock()
                    .unwrap()
                    .as_ref()
                    .map_or(false, |d| d.cancelled);
                match result {
                    Ok(()) => finish_download(&onnx_id, Ok(())),
                    Err(_) if cancelled => finish_download(&onnx_id, Err(String::new())),
                    Err(e) => finish_download(&onnx_id, Err(e)),
                }
            });
            return;
        }
        let id = id.to_string();
        let file = model.file;
        let repo = model.repo;
        thread::spawn(move || {
            let _ = fs::create_dir_all(models_dir());
            let part = models_dir().join(format!("{}.part", file));
            let done = models_dir().join(file);
            let url = format!("https://huggingface.co/{}/resolve/main/{}", repo, file);
            // curl can resume an interrupted download (-C -)
            let spawned = Command::new("curl")
                .args(["-L", "--fail", "--silent", "--show-error", "-C", "-", "-o"])
                .arg(&part)
                .arg(&url)
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::piped())
                .spawn();
            let mut child = match spawned {
                Ok(c) => c,
                Err(e) => {
                    finish_download(&id, Err(format!("Could not start curl: {}", e)));
                    return;
                }
            };
            if let Some(st) = DOWNLOAD.lock().unwrap().as_mut() {
                st.pid = child.id();
            }
            let mut err_text = String::new();
            if let Some(mut stderr) = child.stderr.take() {
                let _ = stderr.read_to_string(&mut err_text);
            }
            let status = child.wait();
            let cancelled = DOWNLOAD
                .lock()
                .unwrap()
                .as_ref()
                .map_or(false, |d| d.cancelled);
            match status {
                Ok(s) if s.success() => match fs::rename(&part, &done) {
                    Ok(_) => finish_download(&id, Ok(())),
                    Err(e) => finish_download(&id, Err(e.to_string())),
                },
                _ if cancelled => finish_download(&id, Err(String::new())),
                _ => {
                    let msg = if err_text.trim().is_empty() {
                        "Download failed.".to_string()
                    } else {
                        err_text.trim().to_string()
                    };
                    finish_download(&id, Err(msg));
                }
            }
        });
    }

    pub fn cancel_download() {
        let pid = {
            let mut st = DOWNLOAD.lock().unwrap();
            match st.as_mut() {
                Some(d) if d.running => {
                    d.cancelled = true;
                    d.pid
                }
                _ => 0,
            }
        };
        if pid != 0 {
            let _ = Command::new("kill").arg(pid.to_string()).status();
        }
    }

    pub fn delete_model(id: &str) {
        if model_engine(id) == Some(Engine::ParakeetOnnx) {
            stop_server();
            let _ = fs::remove_file(onnx_marker());
            let _ = fs::remove_dir_all(onnx_cache_dir());
            return;
        }
        if let Some(m) = MODELS.iter().find(|m| m.id == id) {
            let _ = fs::remove_file(models_dir().join(m.file));
            let _ = fs::remove_file(models_dir().join(format!("{}.part", m.file)));
        }
    }

    // ------------------------------------------------------------ tools

    // whisper-cli (Whisper models) or parakeet-cli (Parakeet models), built by the installer
    fn engine_binary(engine: Engine) -> Option<PathBuf> {
        let names: &[&str] = match engine {
            Engine::Whisper => &["whisper-cli", "whisper-cpp"],
            Engine::Parakeet => &["parakeet-cli"],
            Engine::ParakeetOnnx => &[],
        };
        for name in names {
            let local = data_dir().join("whisper").join(name);
            if local.is_file() {
                return Some(local);
            }
        }
        for name in names {
            if have(name) {
                return Some(PathBuf::from(*name));
            }
        }
        None
    }

    fn missing_engine_message(engine: Engine) -> String {
        match engine {
            Engine::Whisper => "The Whisper engine (whisper-cli) is not installed. Run the installer again.".to_string(),
            Engine::Parakeet => "The Parakeet engine (parakeet-cli) is not installed. Run the installer again.".to_string(),
            Engine::ParakeetOnnx => "The fast Parakeet engine (Python packages) is not installed. Run the installer again.".to_string(),
        }
    }

    fn recorder_tool() -> Option<&'static str> {
        if have("parec") {
            Some("parec")
        } else if have("arecord") {
            Some("arecord")
        } else {
            None
        }
    }

    pub fn requirements(model: &str) -> Vec<(String, bool)> {
        let engine = model_engine(model).unwrap_or(Engine::Parakeet);
        let engine_label = match engine {
            Engine::Whisper => "Voice engine for Whisper models (whisper-cli, built by the installer)",
            Engine::Parakeet => "Voice engine for Parakeet models (parakeet-cli, built by the installer)",
            Engine::ParakeetOnnx => "Fast Parakeet engine (Python + onnx-asr, set up by the installer)",
        };
        vec![
            (engine_label.to_string(), engine_available(engine)),
            (
                "Recording tool (parec from pulseaudio-utils, or arecord)".to_string(),
                recorder_tool().is_some(),
            ),
            (
                "Sound player for the start/stop beeps (paplay, pw-play or aplay)".to_string(),
                sound_player_available(),
            ),
            (
                "A downloaded model (see the list above)".to_string(),
                model_ready(model),
            ),
        ]
    }

    // ------------------------------------------------------------ the fast Parakeet engine

    // A small Python program that loads the Parakeet model once and then reads phrases from us.
    // Request: 4 bytes (length) + 16 kHz mono 16-bit audio. Reply: one line of text.
    const SERVER_SCRIPT: &str = r#"import struct
import sys

import numpy as np
import onnx_asr


def log(message):
    sys.stderr.write(str(message) + "\n")
    sys.stderr.flush()


model = onnx_asr.load_model("nemo-parakeet-tdt-0.6b-v3", quantization="int8")
try:
    model.recognize(np.zeros(16000, dtype=np.float32), sample_rate=16000)
except Exception as error:
    log("warm-up failed: %r" % (error,))

out = sys.stdout.buffer
inp = sys.stdin.buffer
out.write(b"READY\n")
out.flush()


def read_exact(count):
    data = b""
    while len(data) < count:
        chunk = inp.read(count - len(data))
        if not chunk:
            return None
        data += chunk
    return data


while True:
    header = read_exact(4)
    if header is None:
        break
    (size,) = struct.unpack("<I", header)
    payload = read_exact(size) if size else b""
    if payload is None:
        break
    try:
        audio = np.frombuffer(payload, dtype="<i2").astype(np.float32) / 32768.0
        text = model.recognize(audio, sample_rate=16000)
        if not isinstance(text, str):
            text = str(text)
        reply = " ".join(text.split())
    except Exception as error:
        reply = "ERR " + " ".join(repr(error).split())
    out.write(reply.encode("utf-8") + b"\n")
    out.flush()
"#;

    struct Server {
        child: Child,
        stdin: ChildStdin,
        stdout: BufReader<ChildStdout>,
        last_used: Instant,
    }

    static SERVER: Mutex<Option<Server>> = Mutex::new(None);
    static SERVER_STARTING: AtomicBool = AtomicBool::new(false);

    fn python_bin() -> PathBuf {
        data_dir().join("py").join("bin").join("python")
    }

    fn onnx_marker() -> PathBuf {
        data_dir().join("parakeet-onnx.ready")
    }

    fn onnx_cache_dir() -> PathBuf {
        data_dir()
            .join("hf")
            .join("hub")
            .join("models--istupakov--parakeet-tdt-0.6b-v3-onnx")
    }

    fn dir_size(path: &Path) -> u64 {
        let mut total = 0u64;
        if let Ok(entries) = fs::read_dir(path) {
            for e in entries.flatten() {
                if let Ok(md) = e.metadata() {
                    if md.is_dir() {
                        total += dir_size(&e.path());
                    } else {
                        total += md.len();
                    }
                }
            }
        }
        total
    }

    fn engine_available(engine: Engine) -> bool {
        match engine {
            Engine::ParakeetOnnx => python_bin().is_file(),
            _ => engine_binary(engine).is_some(),
        }
    }

    // Starts the helper and waits until the model is loaded (the first time it also downloads the model)
    fn start_server() -> Result<(), String> {
        let python = python_bin();
        if !python.is_file() {
            return Err("The fast Parakeet engine (Python packages) is not installed. Run the installer again.".to_string());
        }
        fs::create_dir_all(data_dir()).map_err(|e| format!("Could not create the data folder: {}", e))?;
        let script = data_dir().join("parakeet_server.py");
        fs::write(&script, SERVER_SCRIPT).map_err(|e| format!("Could not write the helper: {}", e))?;
        let log = fs::File::create(super::config_dir().join("parakeet-server.log"))
            .map_err(|e| format!("Could not create the log file: {}", e))?;

        let mut cmd = Command::new(&python);
        cmd.arg("-u")
            .arg(&script)
            .env("HF_HOME", data_dir().join("hf"))
            .env("PYTHONUNBUFFERED", "1")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::from(log));
        if onnx_marker().is_file() {
            cmd.env("HF_HUB_OFFLINE", "1"); // already downloaded: no network needed
        }
        let mut child = cmd
            .spawn()
            .map_err(|e| format!("Could not start the Parakeet engine: {}", e))?;
        if let Some(st) = DOWNLOAD.lock().unwrap().as_mut() {
            if st.running {
                st.pid = child.id();
            }
        }
        let stdin = child
            .stdin
            .take()
            .ok_or_else(|| "Could not talk to the Parakeet engine.".to_string())?;
        let stdout = child
            .stdout
            .take()
            .ok_or_else(|| "Could not read from the Parakeet engine.".to_string())?;
        let mut reader = BufReader::new(stdout);
        loop {
            let mut line = String::new();
            let n = reader.read_line(&mut line).unwrap_or(0);
            if n == 0 {
                let _ = child.kill();
                let _ = child.wait();
                return Err("The Parakeet engine did not start. See parakeet-server.log in the settings folder.".to_string());
            }
            if line.trim() == "READY" {
                break;
            }
        }
        *SERVER.lock().unwrap() = Some(Server {
            child,
            stdin,
            stdout: reader,
            last_used: Instant::now(),
        });
        let _ = fs::write(onnx_marker(), "ready");
        Ok(())
    }

    fn ensure_server() -> Result<(), String> {
        let began = Instant::now();
        loop {
            if SERVER.lock().unwrap().is_some() {
                return Ok(());
            }
            if !SERVER_STARTING.swap(true, Ordering::SeqCst) {
                let result = start_server();
                SERVER_STARTING.store(false, Ordering::SeqCst);
                return result;
            }
            if began.elapsed() > Duration::from_secs(900) {
                return Err("The Parakeet engine took too long to start.".to_string());
            }
            thread::sleep(Duration::from_millis(200));
        }
    }

    fn stop_server() {
        if let Some(mut s) = SERVER.lock().unwrap().take() {
            let _ = s.child.kill();
            let _ = s.child.wait();
        }
    }

    // Frees the memory (about 1.6 GB) when nothing was dictated for ten minutes
    pub fn start_idle_watch() {
        thread::spawn(|| loop {
            thread::sleep(Duration::from_secs(30));
            let mut guard = SERVER.lock().unwrap();
            let idle = guard
                .as_ref()
                .map_or(false, |s| s.last_used.elapsed() > Duration::from_secs(600));
            if idle && !is_recording() {
                if let Some(mut s) = guard.take() {
                    let _ = s.child.kill();
                    let _ = s.child.wait();
                }
            }
        });
    }

    fn server_recognize(pcm: &[u8]) -> Result<String, String> {
        ensure_server()?;
        let mut guard = SERVER.lock().unwrap();
        let reply: Option<String> = match guard.as_mut() {
            Some(server) => {
                let len = (pcm.len() & !1usize) as u32;
                let outcome: std::io::Result<String> = (|| -> std::io::Result<String> {
                    server.stdin.write_all(&len.to_le_bytes())?;
                    server.stdin.write_all(&pcm[..len as usize])?;
                    server.stdin.flush()?;
                    let mut line = String::new();
                    server.stdout.read_line(&mut line)?;
                    Ok(line)
                })();
                match outcome {
                    Ok(line) if !line.is_empty() => {
                        server.last_used = Instant::now();
                        Some(line)
                    }
                    _ => None,
                }
            }
            None => None,
        };
        match reply {
            Some(line) => {
                let t = line.trim();
                match t.strip_prefix("ERR ") {
                    Some(msg) => Err(format!("The Parakeet engine reported: {}", msg)),
                    None => Ok(t.to_string()),
                }
            }
            None => {
                if let Some(mut dead) = guard.take() {
                    let _ = dead.child.kill();
                    let _ = dead.child.wait();
                }
                Err("The Parakeet engine stopped. Try again.".to_string())
            }
        }
    }

    // ------------------------------------------------------------ sounds

    fn tone(freq: f32, ms: u32, rate: u32, out: &mut Vec<i16>) {
        let n = (rate as u64 * ms as u64 / 1000) as usize;
        let fade = ((rate as usize) * 8 / 1000).max(1); // 8 ms fade: no clicks
        for i in 0..n {
            let t = i as f32 / rate as f32;
            let mut a = (2.0 * std::f32::consts::PI * freq * t).sin() * 0.35;
            if i < fade {
                a *= i as f32 / fade as f32;
            }
            if i + fade > n {
                a *= (n - i) as f32 / fade as f32;
            }
            out.push((a * 32767.0) as i16);
        }
    }

    fn sound_wav(parts: &[(f32, u32)]) -> Vec<u8> {
        let rate = 44100u32;
        let mut samples: Vec<i16> = Vec::new();
        for &(freq, ms) in parts {
            tone(freq, ms, rate, &mut samples);
        }
        let data_len = (samples.len() * 2) as u32;
        let mut v: Vec<u8> = Vec::new();
        v.extend_from_slice(b"RIFF");
        v.extend_from_slice(&(36 + data_len).to_le_bytes());
        v.extend_from_slice(b"WAVEfmt ");
        v.extend_from_slice(&16u32.to_le_bytes());
        v.extend_from_slice(&1u16.to_le_bytes());
        v.extend_from_slice(&1u16.to_le_bytes());
        v.extend_from_slice(&rate.to_le_bytes());
        v.extend_from_slice(&(rate * 2).to_le_bytes());
        v.extend_from_slice(&2u16.to_le_bytes());
        v.extend_from_slice(&16u16.to_le_bytes());
        v.extend_from_slice(b"data");
        v.extend_from_slice(&data_len.to_le_bytes());
        for s in samples {
            v.extend_from_slice(&s.to_le_bytes());
        }
        v
    }

    fn sound_player_available() -> bool {
        have("paplay") || have("pw-play") || have("pw-cat") || have("aplay")
    }

    // Plays a short beep and waits until it is finished. Ok(player used) or Err(why not).
    fn play_report(name: &str) -> Result<String, String> {
        let parts: &[(f32, u32)] = match name {
            "start" => &[(660.0, 70), (880.0, 90)],
            "stop" => &[(880.0, 70), (660.0, 90)],
            _ => &[(300.0, 220)],
        };
        let path = super::config_dir().join(format!("sound-{}.wav", name));
        if !path.is_file() {
            fs::write(&path, sound_wav(parts)).map_err(|e| format!("Could not write the sound file: {}", e))?;
        }
        let file = path.to_string_lossy().to_string();
        let mut tried = false;
        let mut last_error = String::new();
        for (tool, args) in [
            ("paplay", Vec::<&str>::new()),
            ("pw-play", Vec::<&str>::new()),
            ("pw-cat", vec!["--playback"]),
            ("aplay", vec!["-q"]),
        ] {
            if !have(tool) {
                continue;
            }
            tried = true;
            let output = gui_cmd(tool)
                .args(&args)
                .arg(&file)
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::piped())
                .output();
            match output {
                Ok(o) if o.status.success() => return Ok(tool.to_string()),
                Ok(o) => {
                    last_error = format!("{}: {}", tool, String::from_utf8_lossy(&o.stderr).trim());
                }
                Err(e) => {
                    last_error = format!("{}: {}", tool, e);
                }
            }
        }
        if tried {
            Err(last_error)
        } else {
            Err("No sound player found (install pulseaudio-utils or alsa-utils).".to_string())
        }
    }

    // The "Play test sound" button
    pub fn test_sound() -> Result<String, String> {
        play_report("start")
    }

    fn play_blocking(name: &str) -> bool {
        play_report(name).is_ok()
    }

    // If no sound can be played, the start of the listening is shown as a notification instead
    fn beep(cfg: &VoiceConfig, name: &'static str, wait: bool) {
        if !cfg.sounds {
            return;
        }
        let work = move || {
            if !play_blocking(name) && name == "start" {
                notify("Listening...", "Speak now.");
            }
        };
        if wait {
            work();
        } else {
            thread::spawn(work);
        }
    }

    // ------------------------------------------------------------ recording

    struct Recorder {
        child: Child,
        audio: Arc<Mutex<Vec<u8>>>,
        reader: Option<JoinHandle<()>>,
    }

    impl Recorder {
        // Stops recording and returns the audio (16 kHz, mono, 16-bit)
        fn finish(mut self) -> Vec<u8> {
            let _ = self.child.kill();
            let _ = self.child.wait();
            if let Some(h) = self.reader.take() {
                let _ = h.join();
            }
            let bytes = self.audio.lock().unwrap().clone();
            bytes
        }
    }

    fn start_recorder() -> Result<Recorder, String> {
        let (program, args): (&str, Vec<&str>) = match recorder_tool() {
            Some("parec") => (
                "parec",
                vec!["--rate=16000", "--channels=1", "--format=s16le", "--latency-msec=50"],
            ),
            Some(_) => (
                "arecord",
                vec!["-q", "-t", "raw", "-f", "S16_LE", "-r", "16000", "-c", "1"],
            ),
            None => {
                return Err(
                    "No recording tool found. Install pulseaudio-utils (parec) or alsa-utils (arecord)."
                        .to_string(),
                )
            }
        };
        let mut child = gui_cmd(program)
            .args(&args)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("Could not start the microphone recording: {}", e))?;
        let mut stdout = child
            .stdout
            .take()
            .ok_or_else(|| "Could not read the microphone.".to_string())?;
        let audio = Arc::new(Mutex::new(Vec::<u8>::new()));
        let sink = audio.clone();
        let reader = thread::spawn(move || {
            let mut buf = [0u8; 8192];
            loop {
                match stdout.read(&mut buf) {
                    Ok(0) | Err(_) => break,
                    Ok(n) => sink.lock().unwrap().extend_from_slice(&buf[..n]),
                }
            }
        });
        Ok(Recorder {
            child,
            audio,
            reader: Some(reader),
        })
    }

    // ------------------------------------------------------------ splitting speech into phrases

    const FRAME_BYTES: usize = 640; // 20 ms of 16 kHz, 16-bit, mono

    // Cuts the audio into phrases at pauses, so every phrase is read exactly once
    struct Splitter {
        carry: Vec<u8>,
        phrase: Vec<u8>,
        preroll: VecDeque<Vec<u8>>,
        in_phrase: bool,
        speech_frames: usize,
        silence_frames: usize,
        pause_frames: usize,
        noise: f32,
    }

    impl Splitter {
        fn new(pause_ms: u32) -> Splitter {
            Splitter {
                carry: Vec::new(),
                phrase: Vec::new(),
                preroll: VecDeque::new(),
                in_phrase: false,
                speech_frames: 0,
                silence_frames: 0,
                pause_frames: ((pause_ms / 20).max(5)) as usize,
                noise: 150.0,
            }
        }

        fn frame_level(frame: &[u8]) -> f32 {
            let mut sum = 0f64;
            let mut n = 0f64;
            for c in frame.chunks_exact(2) {
                let s = i16::from_le_bytes([c[0], c[1]]) as f64;
                sum += s * s;
                n += 1.0;
            }
            if n == 0.0 {
                0.0
            } else {
                (sum / n).sqrt() as f32
            }
        }

        // The phrase that is still being spoken (None if nothing that sounds like speech yet)
        fn current(&self) -> Option<&[u8]> {
            if self.in_phrase && self.speech_frames >= 6 {
                Some(&self.phrase)
            } else {
                None
            }
        }

        // True while the speaker has just gone quiet (the phrase may end any moment)
        fn in_pause(&self) -> bool {
            self.in_phrase && self.silence_frames >= 4
        }

        // Ends the current phrase; None if it was too short to be speech
        fn take_phrase(&mut self) -> Option<Vec<u8>> {
            let enough = self.speech_frames >= 6;
            let mut phrase = std::mem::take(&mut self.phrase);
            // keep only a short tail of the silence that ended the phrase
            let drop = self.silence_frames.saturating_sub(5) * FRAME_BYTES;
            if drop < phrase.len() {
                let keep = phrase.len() - drop;
                phrase.truncate(keep);
            }
            self.in_phrase = false;
            self.speech_frames = 0;
            self.silence_frames = 0;
            if enough {
                Some(phrase)
            } else {
                None
            }
        }

        fn feed(&mut self, bytes: &[u8]) -> Vec<Vec<u8>> {
            self.carry.extend_from_slice(bytes);
            let mut done: Vec<Vec<u8>> = Vec::new();
            while self.carry.len() >= FRAME_BYTES {
                let frame: Vec<u8> = self.carry.drain(..FRAME_BYTES).collect();
                let level = Self::frame_level(&frame);
                let threshold = (self.noise * 3.0).max(300.0);
                let speaking = level > threshold;
                if !speaking {
                    // learn how loud the room is
                    self.noise = self.noise * 0.98 + level * 0.02;
                }
                if speaking {
                    if !self.in_phrase {
                        self.in_phrase = true;
                        self.phrase.clear();
                        for f in self.preroll.drain(..) {
                            self.phrase.extend_from_slice(&f);
                        }
                    }
                    self.phrase.extend_from_slice(&frame);
                    self.speech_frames += 1;
                    self.silence_frames = 0;
                } else if self.in_phrase {
                    self.phrase.extend_from_slice(&frame);
                    self.silence_frames += 1;
                    if self.silence_frames >= self.pause_frames {
                        if let Some(p) = self.take_phrase() {
                            done.push(p);
                        }
                    }
                } else {
                    self.preroll.push_back(frame);
                    if self.preroll.len() > 10 {
                        self.preroll.pop_front();
                    }
                }
                // never let one phrase grow beyond about 25 seconds
                if self.in_phrase && self.phrase.len() > FRAME_BYTES * 50 * 25 {
                    if let Some(p) = self.take_phrase() {
                        done.push(p);
                    }
                }
            }
            done
        }

        // The recording stopped: whatever is left is the last phrase
        fn flush(&mut self) -> Option<Vec<u8>> {
            if self.in_phrase {
                self.take_phrase()
            } else {
                None
            }
        }
    }

    // ------------------------------------------------------------ speech recognition

    fn peak(pcm: &[u8]) -> i32 {
        pcm.chunks_exact(2)
            .map(|c| (i16::from_le_bytes([c[0], c[1]]) as i32).abs())
            .max()
            .unwrap_or(0)
    }

    fn write_wav(path: &Path, pcm: &[u8]) -> std::io::Result<()> {
        let mut f = fs::File::create(path)?;
        let data_len = pcm.len() as u32;
        f.write_all(b"RIFF")?;
        f.write_all(&(36 + data_len).to_le_bytes())?;
        f.write_all(b"WAVEfmt ")?;
        f.write_all(&16u32.to_le_bytes())?; // size of the fmt chunk
        f.write_all(&1u16.to_le_bytes())?; // PCM
        f.write_all(&1u16.to_le_bytes())?; // mono
        f.write_all(&16000u32.to_le_bytes())?; // sample rate
        f.write_all(&32000u32.to_le_bytes())?; // bytes per second
        f.write_all(&2u16.to_le_bytes())?; // bytes per sample frame
        f.write_all(&16u16.to_le_bytes())?; // bits per sample
        f.write_all(b"data")?;
        f.write_all(&data_len.to_le_bytes())?;
        f.write_all(pcm)?;
        Ok(())
    }

    fn thread_count() -> usize {
        thread::available_parallelism()
            .map(|n| n.get())
            .unwrap_or(4)
            .min(8)
    }

    // "[00:00:00.000 --> 00:00:03.000]  text" -> "text"
    fn strip_timestamp(line: &str) -> &str {
        let t = line.trim();
        if t.starts_with('[') {
            if let Some(i) = t.find(']') {
                if t[..i].contains("-->") {
                    return t[i + 1..].trim();
                }
            }
        }
        t
    }

    fn clean_transcript(raw: &str) -> String {
        let mut parts: Vec<String> = Vec::new();
        for line in raw.lines() {
            let t = strip_timestamp(line);
            if t.is_empty() {
                continue;
            }
            // markers such as [BLANK_AUDIO] or (music), and engine log lines
            if (t.starts_with('[') && t.ends_with(']')) || (t.starts_with('(') && t.ends_with(')')) {
                continue;
            }
            if t.starts_with("ggml_")
                || t.starts_with("whisper_")
                || t.starts_with("parakeet_")
                || t.starts_with("system_info")
                || t.starts_with("main:")
            {
                continue;
            }
            parts.push(t.to_string());
        }
        parts.join(" ")
    }

    // Characters the virtual keyboard can type
    fn for_typing(s: &str) -> String {
        let mapped: String = s
            .chars()
            .map(|c| match c {
                '\u{2018}' | '\u{2019}' => '\'',
                '\u{201c}' | '\u{201d}' | '\u{201e}' => '"',
                '\u{2013}' | '\u{2014}' => '-',
                '\u{a0}' => ' ',
                _ => c,
            })
            .collect();
        mapped.replace('\u{2026}', "...")
    }

    // Reads the speech in `pcm` with the selected model
    fn run_engine(pcm: &[u8], cfg: &VoiceConfig, tag: &str) -> Result<String, String> {
        if pcm.len() < 8000 {
            return Ok(String::new()); // shorter than a quarter of a second
        }
        if peak(pcm) < 300 {
            return Ok(String::new()); // silence
        }
        let engine = model_engine(&cfg.model).ok_or_else(|| "Unknown model.".to_string())?;
        if engine == Engine::ParakeetOnnx {
            if !model_ready(&cfg.model) {
                return Err("The fast Parakeet engine is not set up yet. Open the Voice tab and press Download on it.".to_string());
            }
            return server_recognize(pcm).map(|t| clean_transcript(&t));
        }
        let bin = engine_binary(engine).ok_or_else(|| missing_engine_message(engine))?;
        let model = model_file(&cfg.model)
            .filter(|p| p.is_file())
            .ok_or_else(|| "The selected model is not downloaded.".to_string())?;
        let wav = std::env::temp_dir().join(format!(
            "expander-voice-{}-{}.wav",
            std::process::id(),
            tag
        ));
        write_wav(&wav, pcm).map_err(|e| format!("Could not write the audio: {}", e))?;

        let mut cmd = Command::new(&bin);
        cmd.arg("-m").arg(&model).arg("-f").arg(&wav);
        if engine == Engine::Whisper {
            cmd.arg("-l")
                .arg(&cfg.language)
                .arg("-t")
                .arg(thread_count().to_string())
                .arg("-nt")
                .arg("-np");
        }
        cmd.stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        let output = cmd.output();
        let _ = fs::remove_file(&wav);
        let output = output.map_err(|e| format!("Could not run the voice engine: {}", e))?;
        if !output.status.success() {
            let err = String::from_utf8_lossy(&output.stderr).to_string();
            let last = err
                .lines()
                .rev()
                .find(|l| !l.trim().is_empty())
                .unwrap_or("")
                .trim()
                .to_string();
            return Err(format!("The voice engine failed: {}", last));
        }
        Ok(clean_transcript(&String::from_utf8_lossy(&output.stdout)))
    }

    // ------------------------------------------------------------ timing information

    fn stats_path() -> PathBuf {
        super::config_dir().join("voice_stats.txt")
    }

    // The last few readings of the background service (shown in the Voice tab)
    pub fn read_stats() -> String {
        fs::read_to_string(stats_path()).unwrap_or_default()
    }

    fn log_stat(line: String) {
        let mut lines: Vec<String> = fs::read_to_string(stats_path())
            .unwrap_or_default()
            .lines()
            .map(|l| l.to_string())
            .collect();
        lines.push(line);
        while lines.len() > 8 {
            lines.remove(0);
        }
        let _ = fs::write(stats_path(), lines.join("\n"));
    }

    fn record_stats(_lines: &mut Vec<String>, kind: &str, audio_bytes: usize, secs: f32) {
        log_stat(format!(
            "{}: {:.1} s to read {:.1} s of speech",
            kind,
            secs,
            audio_bytes as f32 / 32000.0
        ));
    }

    // Hands text to the typing keyboard and notes it in the log
    fn type_and_log(text: &str) {
        let typed = for_typing(text);
        let count = typed.chars().count();
        let sent = super::input::type_text(typed);
        if sent {
            log_stat(format!("typed {} characters", count));
        } else {
            log_stat(format!("could not type {} characters: the typing keyboard is not ready", count));
        }
    }

    static LAST_WARM: Mutex<Option<Instant>> = Mutex::new(None);

    // Reads the model file once so that the first phrase does not wait for the disk
    fn warm_model(id: &str) {
        let path = match model_file(id) {
            Some(p) => p,
            None => return,
        };
        {
            let mut last = LAST_WARM.lock().unwrap();
            if (*last).map_or(false, |t| t.elapsed() < Duration::from_secs(300)) {
                return;
            }
            *last = Some(Instant::now());
        }
        thread::spawn(move || {
            if let Ok(mut f) = fs::File::open(&path) {
                let _ = std::io::copy(&mut f, &mut std::io::sink());
            }
        });
    }

    // ------------------------------------------------------------ live text

    fn last_chars(text: &str, n: usize) -> String {
        let count = text.chars().count();
        if count <= n {
            text.to_string()
        } else {
            let tail: String = text.chars().skip(count - n).collect();
            format!("...{}", tail)
        }
    }

    fn notify_live(title: &str, body: &str, id: &mut Option<String>) {
        let mut cmd = gui_cmd("notify-send");
        cmd.args(["-a", "Text Expander", "-t", "20000", "-p"]);
        if let Some(i) = id.as_ref() {
            cmd.arg("-r").arg(i);
        }
        cmd.arg(title)
            .arg(body)
            .stdin(Stdio::null())
            .stderr(Stdio::null());
        if let Ok(out) = cmd.output() {
            if id.is_none() {
                let s = String::from_utf8_lossy(&out.stdout).trim().to_string();
                if !s.is_empty() {
                    *id = Some(s);
                }
            }
        }
    }

    fn show_live(style: &str, text: &str, id: &mut Option<String>) {
        let tail = last_chars(text, 200);
        if style == "box" {
            let _ = fs::write(live_path(), tail);
        } else {
            notify_live("Listening...", &tail, id);
        }
    }

    // The box on screen is a small separate window (the program started with --overlay).
    // It is forced onto X11 (Xwayland) so that it can stay on top without taking the keyboard focus.
    fn spawn_overlay() -> Option<Child> {
        let exe = std::env::current_exe().ok()?;
        let exe_str = exe.to_str()?.to_string();
        let _ = fs::write(live_path(), "");
        let _ = fs::remove_file(super::config_dir().join("voice_close"));
        let _ = fs::remove_file(super::config_dir().join("voice_note.txt"));
        let _ = fs::write(super::config_dir().join("voice_level.txt"), "0");
        let mut cmd = gui_cmd(&exe_str);
        cmd.arg("--overlay")
            .env_remove("WAYLAND_DISPLAY")
            .env("WINIT_UNIX_BACKEND", "x11")
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null());
        let mut child = cmd.spawn().ok()?;
        thread::sleep(Duration::from_millis(700));
        match child.try_wait() {
            Ok(None) => Some(child),
            _ => None,
        }
    }

    static REVIEW_OPEN: AtomicBool = AtomicBool::new(false);

    // Shows the text in a window where it can be corrected. What is sent from there is typed at the cursor.
    fn review_and_type(text: String) {
        if REVIEW_OPEN.swap(true, Ordering::SeqCst) {
            return;
        }
        let input = super::config_dir().join("voice_review_in.txt");
        let output = super::config_dir().join("voice_review_out.txt");
        let _ = fs::write(&input, &text);
        let _ = fs::remove_file(&output);
        let exe = std::env::current_exe()
            .ok()
            .and_then(|e| e.to_str().map(|s| s.to_string()));
        let mut opened = false;
        if let Some(exe_str) = exe {
            let spawned = gui_cmd(&exe_str)
                .arg("--review")
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .spawn();
            if let Ok(mut child) = spawned {
                opened = true;
                let _ = child.wait();
            }
        }
        let sent = fs::read_to_string(&output).ok();
        let _ = fs::remove_file(&output);
        let _ = fs::remove_file(&input);
        REVIEW_OPEN.store(false, Ordering::SeqCst);
        if !opened {
            notify("Voice typing", "Could not open the edit box, so the text is typed directly.");
            type_and_log(&text);
            return;
        }
        if let Some(final_text) = sent {
            if !final_text.trim().is_empty() {
                // give the focus time to go back to the program the text is meant for
                thread::sleep(Duration::from_millis(350));
                type_and_log(final_text.trim());
            }
        }
    }

    // Asks the box to close itself (a clean close, so the desktop removes it at once)
    fn close_overlay(mut child: Child) {
        let marker = super::config_dir().join("voice_close");
        let _ = fs::write(&marker, "close");
        for _ in 0..40 {
            if let Ok(Some(_)) = child.try_wait() {
                let _ = fs::remove_file(&marker);
                return;
            }
            thread::sleep(Duration::from_millis(50));
        }
        let _ = child.kill();
        let _ = child.wait();
        let _ = fs::remove_file(&marker);
    }

    fn note_path() -> PathBuf {
        super::config_dir().join("voice_note.txt")
    }

    fn level_path() -> PathBuf {
        super::config_dir().join("voice_level.txt")
    }

    // ------------------------------------------------------------ what fits this computer

    pub struct Hardware {
        pub cpu: String,
        pub cores: usize,
        pub ram_mb: u64,
    }

    pub fn hardware() -> Hardware {
        let cpu = fs::read_to_string("/proc/cpuinfo")
            .unwrap_or_default()
            .lines()
            .find(|l| l.starts_with("model name"))
            .and_then(|l| l.split(':').nth(1))
            .map(|v| v.trim().to_string())
            .unwrap_or_else(|| "unknown processor".to_string());
        let ram_kb: u64 = fs::read_to_string("/proc/meminfo")
            .unwrap_or_default()
            .lines()
            .find(|l| l.starts_with("MemTotal:"))
            .and_then(|l| l.split_whitespace().nth(1))
            .and_then(|v| v.parse().ok())
            .unwrap_or(0);
        let cores = thread::available_parallelism().map(|n| n.get()).unwrap_or(1);
        Hardware {
            cpu,
            cores,
            ram_mb: ram_kb / 1024,
        }
    }

    // A first guess from the hardware alone
    pub fn suggested_model(hw: &Hardware) -> &'static str {
        if hw.ram_mb >= 4000 && hw.cores >= 2 {
            "parakeet-onnx"
        } else if hw.ram_mb < 3500 || hw.cores <= 2 {
            "parakeet-q4_0"
        } else if hw.ram_mb < 6500 || hw.cores <= 4 {
            "parakeet-q4_k"
        } else {
            "parakeet-q8_0"
        }
    }

    // Records 5 seconds, reads the same audio with every downloaded model and times each one.
    // Returns the text for the window and the best model that is fast enough.
    pub fn benchmark(
        cfg: VoiceConfig,
        progress: Arc<Mutex<String>>,
    ) -> Result<(String, Option<String>), String> {
        if is_recording() {
            return Err("A recording is already running.".to_string());
        }
        let set = |m: &str| {
            *progress.lock().unwrap() = m.to_string();
        };
        set("Speak for 5 seconds...");
        beep(&cfg, "start", true);
        let recorder = start_recorder()?;
        thread::sleep(Duration::from_secs(5));
        let pcm = recorder.finish();
        beep(&cfg, "stop", true);
        if peak(&pcm) < 300 {
            return Err("I could not hear you. Speak clearly for the 5 seconds and try again.".to_string());
        }
        let audio_secs = pcm.len() as f32 / 32000.0;

        let mut rows: Vec<(String, f32)> = Vec::new();
        for m in MODELS {
            if !model_ready(m.id) {
                continue;
            }
            set(&format!("Reading with {} ...", m.id));
            let mut c = cfg.clone();
            c.model = m.id.to_string();
            if m.engine == Engine::ParakeetOnnx {
                // do not count the one-time start of the helper
                let _ = ensure_server();
                let _ = run_engine(&pcm, &c, "bench");
            }
            let started = Instant::now();
            if run_engine(&pcm, &c, "bench").is_ok() {
                rows.push((m.id.to_string(), started.elapsed().as_secs_f32()));
            }
        }
        if rows.is_empty() {
            return Err("No downloaded model could be tested. Download a model first.".to_string());
        }

        // From best quality to worst; the best one that is fast enough wins
        let order = [
            "large-v3",
            "large-v3-q5_0",
            "large-v3-turbo",
            "parakeet-onnx",
            "parakeet-q8_0",
            "large-v3-turbo-q5_0",
            "parakeet-q4_k",
            "medium-q5_0",
            "parakeet-q4_0",
            "small-q5_1",
            "base-q5_1",
            "tiny-q5_1",
        ];
        let fast_enough = audio_secs * 0.4;
        let mut best: Option<String> = None;
        for id in order {
            if let Some((_, secs)) = rows.iter().find(|(r, _)| r == id) {
                if *secs <= fast_enough {
                    best = Some(id.to_string());
                    break;
                }
            }
        }
        if best.is_none() {
            best = rows
                .iter()
                .min_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal))
                .map(|r| r.0.clone());
        }

        let mut text = format!("Tested with {:.1} s of your speech:\n", audio_secs);
        for (id, secs) in &rows {
            let verdict = if *secs <= fast_enough {
                "fast enough"
            } else if *secs <= audio_secs {
                "usable, with a delay"
            } else {
                "too slow"
            };
            text.push_str(&format!("  {}: {:.1} s - {}\n", id, secs, verdict));
        }
        Ok((text, best))
    }

    // ------------------------------------------------------------ one dictation

    // Runs while recording: cuts the speech into phrases at every pause and reads each phrase once.
    // Between pauses it also reads the phrase that is still being spoken, for the live text.
    // Returns the phrases when the recording has stopped.
    fn spawn_worker(
        audio: Arc<Mutex<Vec<u8>>>,
        stop: Arc<AtomicBool>,
        had_error: Arc<AtomicBool>,
        cfg: VoiceConfig,
        style: String,
        type_live: bool,
    ) -> JoinHandle<Vec<String>> {
        thread::spawn(move || {
            let mut splitter = Splitter::new(cfg.pause_ms);
            let mut cursor = 0usize;
            let mut phrases: Vec<String> = Vec::new();
            let mut notif_id: Option<String> = None;
            let mut stats: Vec<String> = Vec::new();
            let mut last_preview_len = 0usize;
            let mut preview_on = !style.is_empty();
            let mut slow_previews = 0u32;
            let mut last_level_write = Instant::now();
            loop {
                let stopping = stop.load(Ordering::SeqCst);
                let fresh: Vec<u8> = {
                    let a = audio.lock().unwrap();
                    let end = a.len() & !1usize;
                    if end > cursor {
                        let v = a[cursor..end].to_vec();
                        cursor = end;
                        v
                    } else {
                        Vec::new()
                    }
                };
                // how loud it is right now (for the level bar in the box)
                if style == "box" && !fresh.is_empty() && last_level_write.elapsed() > Duration::from_millis(100) {
                    last_level_write = Instant::now();
                    let tail = &fresh[fresh.len().saturating_sub(3200)..];
                    let level = (Splitter::frame_level(tail) / 3000.0).min(1.0);
                    let _ = fs::write(level_path(), format!("{:.2}", level));
                }
                let mut ready = splitter.feed(&fresh);
                if stopping {
                    if let Some(last) = splitter.flush() {
                        ready.push(last);
                    }
                }
                if !ready.is_empty() {
                    last_preview_len = 0;
                }
                for pcm in ready {
                    let started = Instant::now();
                    match run_engine(&pcm, &cfg, "phrase") {
                        Ok(text) => {
                            record_stats(&mut stats, "phrase", pcm.len(), started.elapsed().as_secs_f32());
                            if !text.is_empty() {
                                phrases.push(text.clone());
                                if !style.is_empty() {
                                    show_live(&style, &phrases.join(" "), &mut notif_id);
                                }
                                if type_live {
                                    type_and_log(&text);
                                }
                            }
                        }
                        Err(e) => {
                            had_error.store(true, Ordering::SeqCst);
                            beep(&cfg, "error", false);
                            notify("Voice typing failed", &e);
                        }
                    }
                }

                // Live preview of the phrase that is still being spoken. It is skipped when the
                // speaker has just paused (the phrase is about to be finished anyway), and it
                // switches itself off for the rest of the recording if reading is too slow.
                if !stopping && preview_on && !splitter.in_pause() {
                    let current: Option<Vec<u8>> = splitter.current().map(|c| c.to_vec());
                    if let Some(cur) = current {
                        if cur.len() >= last_preview_len + 24000 {
                            last_preview_len = cur.len();
                            let started = Instant::now();
                            if let Ok(text) = run_engine(&cur, &cfg, "preview") {
                                let took = started.elapsed().as_secs_f32();
                                record_stats(&mut stats, "preview", cur.len(), took);
                                if !text.is_empty() && !stop.load(Ordering::SeqCst) {
                                    let mut shown = phrases.join(" ");
                                    if !shown.is_empty() {
                                        shown.push(' ');
                                    }
                                    shown.push_str(&text);
                                    show_live(&style, &shown, &mut notif_id);
                                }
                                if took > 2.5 {
                                    slow_previews += 1;
                                    if slow_previews >= 2 {
                                        preview_on = false;
                                        let _ = fs::write(
                                            note_path(),
                                            "Words while you speak are paused: this computer reads slowly. Pick a faster model in the Voice tab.",
                                        );
                                    }
                                }
                            }
                        }
                    }
                }
                if stopping {
                    break;
                }
                thread::sleep(Duration::from_millis(40));
            }
            phrases
        })
    }

    struct Session {
        recorder: Recorder,
        stop: Arc<AtomicBool>,
        had_error: Arc<AtomicBool>,
        worker: JoinHandle<Vec<String>>,
        overlay: Option<Child>,
        type_live: bool,
    }

    static SESSION: Mutex<Option<Session>> = Mutex::new(None);

    pub fn is_recording() -> bool {
        SESSION.lock().unwrap().is_some()
    }

    pub fn start(cfg: &VoiceConfig) {
        let mut guard = SESSION.lock().unwrap();
        if guard.is_some() {
            return;
        }
        if REVIEW_OPEN.load(Ordering::SeqCst) {
            notify("Voice typing", "Send or close the edit box first.");
            return;
        }
        if !model_ready(&cfg.model) {
            beep(cfg, "error", false);
            notify(
                "Voice typing",
                "Download a model first: open Text Expander > Voice typing.",
            );
            return;
        }
        let engine = model_engine(&cfg.model).unwrap_or(Engine::Parakeet);
        if !engine_available(engine) {
            beep(cfg, "error", false);
            notify("Voice typing", &missing_engine_message(engine));
            return;
        }
        if engine == Engine::ParakeetOnnx {
            // load the helper while the first words are spoken
            thread::spawn(|| {
                let _ = ensure_server();
            });
        } else {
            warm_model(&cfg.model);
        }
        // The start beep plays first, so that the microphone does not pick it up
        beep(cfg, "start", true);
        let recorder = match start_recorder() {
            Ok(r) => r,
            Err(e) => {
                beep(cfg, "error", false);
                notify("Voice typing", &e);
                return;
            }
        };
        let stop = Arc::new(AtomicBool::new(false));
        let had_error = Arc::new(AtomicBool::new(false));
        let mut overlay: Option<Child> = None;
        let mut style = String::new();
        if cfg.live {
            style = cfg.live_style.clone();
            if style == "box" {
                overlay = spawn_overlay();
                if overlay.is_none() {
                    style = "notification".to_string(); // the box could not start
                }
            }
        } else if !cfg.sounds {
            notify("Listening...", "Speak now.");
        }
        // Typing while a key is held would turn the text into shortcuts, so only in toggle mode.
        // With the edit box nothing is typed before the user sends the text.
        let type_live = cfg.type_live && cfg.mode == "toggle" && !cfg.review;
        let worker = spawn_worker(
            recorder.audio.clone(),
            stop.clone(),
            had_error.clone(),
            cfg.clone(),
            style,
            type_live,
        );
        *guard = Some(Session {
            recorder,
            stop,
            had_error,
            worker,
            overlay,
            type_live,
        });
    }

    // Stop recording; the last phrase is read and typed
    pub fn stop_and_type(cfg: VoiceConfig) {
        let session = SESSION.lock().unwrap().take();
        let session = match session {
            Some(s) => s,
            None => return,
        };
        let Session {
            recorder,
            stop,
            had_error,
            worker,
            overlay,
            type_live,
        } = session;
        beep(&cfg, "stop", false);
        let _ = recorder.finish(); // the worker reads the rest of the audio
        stop.store(true, Ordering::SeqCst);
        let review = cfg.review;
        // close the box right away; the last phrase is still being read
        if let Some(child) = overlay {
            thread::spawn(move || close_overlay(child));
        }
        thread::spawn(move || {
            let phrases = worker.join().unwrap_or_default();
            let _ = fs::remove_file(live_path());
            if phrases.is_empty() {
                if !had_error.load(Ordering::SeqCst) {
                    notify("Voice typing", "No speech detected.");
                }
                return;
            }
            if review {
                review_and_type(phrases.join(" "));
            } else if !type_live {
                thread::sleep(Duration::from_millis(150));
                type_and_log(&phrases.join(" "));
            }
        });
    }

    pub fn toggle(cfg: VoiceConfig) {
        if is_recording() {
            stop_and_type(cfg);
        } else {
            start(&cfg);
        }
    }

    // Used when a held key is released
    pub fn stop_if_recording(cfg: VoiceConfig) {
        if is_recording() {
            stop_and_type(cfg);
        }
    }

    // Used by the "Test" button in the window: records, shows the text and how long it took, types nothing
    pub fn test_once(cfg: VoiceConfig, seconds: u64) -> Result<String, String> {
        if is_recording() {
            return Err("A recording is already running.".to_string());
        }
        beep(&cfg, "start", true);
        let recorder = start_recorder()?;
        thread::sleep(Duration::from_secs(seconds));
        let pcm = recorder.finish();
        beep(&cfg, "stop", true);
        let started = Instant::now();
        let text = run_engine(&pcm, &cfg, "test")?;
        if text.is_empty() {
            Ok(text)
        } else {
            Ok(format!("{}  ({:.1} s)", text, started.elapsed().as_secs_f32()))
        }
    }
}

#[cfg(target_os = "linux")]
mod input {
    use super::Shared;
    use evdev::{
        uinput::{VirtualDevice, VirtualDeviceBuilder},
        AttributeSet, EventType, InputEvent, Key,
    };
    use std::{
        sync::{
            atomic::{AtomicBool, Ordering},
            mpsc, Arc,
        },
        thread,
        time::Duration,
    };

    const VNAME: &str = "expander-virtual-keyboard";
    const SPACE: u16 = 57;
    const BACKSPACE: u16 = 14;
    const LSHIFT: u16 = 42;
    const ALTGR: u16 = 100;

    // (character, key code, needs Shift, needs AltGr)
    type Sym = (char, u16, bool, bool);

    // Letters a-z and digits 0-9: same key positions on US and Finnish layouts.
    const CHARS: &[(u16, char)] = &[
        (30, 'a'), (48, 'b'), (46, 'c'), (32, 'd'), (18, 'e'), (33, 'f'), (34, 'g'),
        (35, 'h'), (23, 'i'), (36, 'j'), (37, 'k'), (38, 'l'), (50, 'm'), (49, 'n'),
        (24, 'o'), (25, 'p'), (16, 'q'), (19, 'r'), (31, 's'), (20, 't'), (22, 'u'),
        (47, 'v'), (17, 'w'), (45, 'x'), (21, 'y'), (44, 'z'),
        (2, '1'), (3, '2'), (4, '3'), (5, '4'), (6, '5'), (7, '6'), (8, '7'),
        (9, '8'), (10, '9'), (11, '0'),
    ];

    const US: &[Sym] = &[
        ('!', 2, true, false), ('@', 3, true, false), ('#', 4, true, false),
        ('$', 5, true, false), ('%', 6, true, false), ('^', 7, true, false),
        ('&', 8, true, false), ('*', 9, true, false), ('(', 10, true, false),
        (')', 11, true, false),
        ('-', 12, false, false), ('_', 12, true, false),
        ('=', 13, false, false), ('+', 13, true, false),
        ('[', 26, false, false), ('{', 26, true, false),
        (']', 27, false, false), ('}', 27, true, false),
        (';', 39, false, false), (':', 39, true, false),
        ('\'', 40, false, false), ('"', 40, true, false),
        ('`', 41, false, false), ('~', 41, true, false),
        ('\\', 43, false, false), ('|', 43, true, false),
        (',', 51, false, false), ('<', 51, true, false),
        ('.', 52, false, false), ('>', 52, true, false),
        ('/', 53, false, false), ('?', 53, true, false),
    ];

    // Finnish / Swedish (Nordic) layout
    const FI: &[Sym] = &[
        ('!', 2, true, false), ('"', 3, true, false), ('@', 3, false, true),
        ('#', 4, true, false), ('$', 5, false, true), ('%', 6, true, false),
        ('&', 7, true, false), ('/', 8, true, false), ('{', 8, false, true),
        ('(', 9, true, false), ('[', 9, false, true), (')', 10, true, false),
        (']', 10, false, true), ('=', 11, true, false), ('}', 11, false, true),
        ('+', 12, false, false), ('?', 12, true, false), ('\\', 12, false, true),
        ('å', 26, false, false), ('ö', 39, false, false), ('ä', 40, false, false),
        ('\'', 43, false, false), ('*', 43, true, false),
        (',', 51, false, false), (';', 51, true, false),
        ('.', 52, false, false), (':', 52, true, false),
        ('-', 53, false, false), ('_', 53, true, false),
        ('<', 86, false, false), ('>', 86, true, false), ('|', 86, false, true),
    ];

    // Danish layout
    const DK: &[Sym] = &[
        ('!', 2, true, false), ('"', 3, true, false), ('@', 3, false, true),
        ('#', 4, true, false), ('$', 5, false, true), ('%', 6, true, false),
        ('&', 7, true, false), ('/', 8, true, false), ('{', 8, false, true),
        ('(', 9, true, false), ('[', 9, false, true), (')', 10, true, false),
        (']', 10, false, true), ('=', 11, true, false), ('}', 11, false, true),
        ('+', 12, false, false), ('?', 12, true, false),
        ('|', 13, false, true),
        ('å', 26, false, false), ('ø', 39, false, false), ('æ', 40, false, false),
        ('\'', 43, false, false), ('*', 43, true, false),
        (',', 51, false, false), (';', 51, true, false),
        ('.', 52, false, false), (':', 52, true, false),
        ('-', 53, false, false), ('_', 53, true, false),
        ('<', 86, false, false), ('>', 86, true, false), ('\\', 86, false, true),
    ];

    #[derive(Clone, Copy)]
    struct Keymap {
        name: &'static str,
        symbols: &'static [Sym],
    }

    impl Keymap {
        // What character does this key produce with the given modifiers?
        fn char_of(&self, code: u16, shift: bool, altgr: bool) -> Option<char> {
            if let Some((c, _, _, _)) = self
                .symbols
                .iter()
                .copied()
                .find(|&(_, k, s, a)| k == code && s == shift && a == altgr)
            {
                return Some(c);
            }
            if altgr {
                return None;
            }
            if let Some((_, c)) = CHARS.iter().copied().find(|&(k, _)| k == code) {
                if c.is_ascii_alphabetic() || !shift {
                    return Some(c);
                }
                return None;
            }
            if shift {
                // Shifted ä/ö/å -> treat as the lowercase letter
                if let Some((c, _, _, _)) = self
                    .symbols
                    .iter()
                    .copied()
                    .find(|&(_, k, s, a)| k == code && !s && !a)
                {
                    if c.is_alphabetic() {
                        return Some(c);
                    }
                }
            }
            None
        }

        // Which key (and modifiers) types this character?
        fn keys_of(&self, c: char) -> Option<(u16, bool, bool)> {
            if c == ' ' {
                return Some((SPACE, false, false));
            }
            if let Some((_, k, s, a)) = self.symbols.iter().copied().find(|&(ch, _, _, _)| ch == c) {
                return Some((k, s, a));
            }
            let lower = c.to_lowercase().next()?;
            let shift = c != lower;
            if let Some((k, _)) = CHARS.iter().copied().find(|&(_, ch)| ch == lower) {
                return Some((k, shift, false));
            }
            self.symbols
                .iter()
                .copied()
                .find(|&(ch, _, s, a)| ch == lower && !s && !a)
                .map(|(_, k, _, _)| (k, shift, false))
        }
    }

    // English (UK) layout
    const UK: &[Sym] = &[
        ('!', 2, true, false), ('"', 3, true, false), ('£', 4, true, false),
        ('$', 5, true, false), ('%', 6, true, false), ('^', 7, true, false),
        ('&', 8, true, false), ('*', 9, true, false), ('(', 10, true, false),
        (')', 11, true, false),
        ('-', 12, false, false), ('_', 12, true, false),
        ('=', 13, false, false), ('+', 13, true, false),
        ('[', 26, false, false), ('{', 26, true, false),
        (']', 27, false, false), ('}', 27, true, false),
        (';', 39, false, false), (':', 39, true, false),
        ('\'', 40, false, false), ('@', 40, true, false),
        ('`', 41, false, false),
        ('#', 43, false, false), ('~', 43, true, false),
        (',', 51, false, false), ('<', 51, true, false),
        ('.', 52, false, false), ('>', 52, true, false),
        ('/', 53, false, false), ('?', 53, true, false),
        ('\\', 86, false, false), ('|', 86, true, false),
    ];

    // Layout code ("dk", "us", "uk", "fi") -> keymap. Anything else -> None.
    fn keymap_for(code: &str) -> Option<Keymap> {
        match code {
            "dk" => Some(Keymap { name: "Danish", symbols: DK }),
            "fi" | "se" => Some(Keymap { name: "Finnish/Swedish", symbols: FI }),
            "gb" | "uk" => Some(Keymap { name: "English (UK)", symbols: UK }),
            "us" => Some(Keymap { name: "English (US)", symbols: US }),
            _ => None,
        }
    }

    fn parse_layout(v: &str) -> Keymap {
        let first = v.split(',').next().unwrap_or("").trim().to_lowercase();
        keymap_for(&first).unwrap_or(Keymap { name: "English (US)", symbols: US })
    }

    fn all_symbols() -> impl Iterator<Item = Sym> {
        US.iter().chain(UK).chain(FI).chain(DK).copied()
    }

    fn detect_keymap() -> Keymap {
        let home = std::env::var("HOME").unwrap_or_default();
        if let Ok(s) = std::fs::read_to_string(format!("{home}/.config/kxkbrc")) {
            for line in s.lines() {
                if let Some(v) = line.trim().strip_prefix("LayoutList=") {
                    return parse_layout(v);
                }
            }
        }
        // Fallback (checked only once, since it starts a process)
        static FALLBACK: std::sync::OnceLock<String> = std::sync::OnceLock::new();
        let v = FALLBACK.get_or_init(|| {
            if let Ok(out) = std::process::Command::new("localectl").arg("status").output() {
                let t = String::from_utf8_lossy(&out.stdout).to_string();
                for line in t.lines() {
                    if let Some(v) = line.trim().strip_prefix("X11 Layout:") {
                        return v.trim().to_string();
                    }
                }
            }
            "us".to_string()
        });
        parse_layout(v)
    }

    // The saved setting is "auto" or a layout code ("dk", "us", "uk", "fi").
    fn resolve(setting: &str) -> Keymap {
        keymap_for(setting).unwrap_or_else(detect_keymap)
    }

    fn bump(n: &mut i32, val: i32) {
        if val == 1 {
            *n += 1;
        } else if val == 0 {
            *n = (*n - 1).max(0);
        }
    }

    // A global shortcut such as "Ctrl+Alt+O"
    struct Hotkey {
        ctrl: bool,
        alt: bool,
        shift: bool,
        meta: bool,
        key: u16,
    }

    fn key_code_for_name(name: &str) -> Option<u16> {
        let mut chars = name.chars();
        if let (Some(c), None) = (chars.next(), chars.next()) {
            return CHARS.iter().copied().find(|&(_, ch)| ch == c).map(|(k, _)| k);
        }
        let n: u16 = name.strip_prefix('f')?.parse().ok()?;
        match n {
            1..=10 => Some(58 + n),
            11 => Some(87),
            12 => Some(88),
            _ => None,
        }
    }

    fn parse_hotkey(s: &str) -> Option<Hotkey> {
        let mut hk = Hotkey {
            ctrl: false,
            alt: false,
            shift: false,
            meta: false,
            key: 0,
        };
        for part in s.split('+').map(|p| p.trim().to_lowercase()).filter(|p| !p.is_empty()) {
            match part.as_str() {
                "ctrl" | "control" => hk.ctrl = true,
                "alt" => hk.alt = true,
                "shift" => hk.shift = true,
                "meta" | "super" | "win" => hk.meta = true,
                other => hk.key = key_code_for_name(other)?,
            }
        }
        if hk.key == 0 {
            None
        } else {
            Some(hk)
        }
    }

    // Lets other parts of the program (voice typing) type text at the cursor
    pub static TYPER: std::sync::OnceLock<std::sync::Mutex<mpsc::Sender<(usize, String, bool)>>> =
        std::sync::OnceLock::new();

    pub fn type_text(text: String) -> bool {
        match TYPER.get() {
            Some(t) => t.lock().unwrap().send((0, text, true)).is_ok(),
            None => false,
        }
    }

    // How many modifier keys (Shift, Ctrl, Alt, AltGr, Meta) are held down on any keyboard right now
    pub static GLOBAL_MODS: std::sync::atomic::AtomicI32 = std::sync::atomic::AtomicI32::new(0);

    // Presses Ctrl+C for the user (used to copy the selected text). It first waits until the keys of
    // the shortcut have been released, otherwise the program would see Ctrl+Alt+C or similar.
    pub fn press_copy() -> bool {
        let began = std::time::Instant::now();
        while GLOBAL_MODS.load(Ordering::SeqCst) > 0 && began.elapsed() < Duration::from_millis(2000) {
            thread::sleep(Duration::from_millis(30));
        }
        thread::sleep(Duration::from_millis(60));
        match TYPER.get() {
            Some(t) => t
                .lock()
                .unwrap()
                .send((0, "\u{1}COPY".to_string(), false))
                .is_ok(),
            None => false,
        }
    }

    // An expansion waiting for the physical keys to be released before it is typed
    struct Pending {
        key: u16,
        released: bool,
        job: (usize, String, bool),
    }

    fn tap(vd: &mut VirtualDevice, code: u16, shift: bool, altgr: bool) {
        let ev = |c: u16, v: i32| InputEvent::new(EventType::KEY, c, v);
        if shift {
            let _ = vd.emit(&[ev(LSHIFT, 1)]);
        }
        if altgr {
            let _ = vd.emit(&[ev(ALTGR, 1)]);
        }
        let _ = vd.emit(&[ev(code, 1)]);
        let _ = vd.emit(&[ev(code, 0)]);
        if altgr {
            let _ = vd.emit(&[ev(ALTGR, 0)]);
        }
        if shift {
            let _ = vd.emit(&[ev(LSHIFT, 0)]);
        }
        thread::sleep(Duration::from_millis(8));
    }

    pub fn start_listener(
        entries: Shared,
        enabled: Arc<AtomicBool>,
        layout: super::LayoutSetting,
        ocr: super::OcrShared,
        voice: super::VoiceShared,
        speak: super::SpeakShared,
    ) {
        let initial = resolve(&layout.lock().unwrap());
        eprintln!("Using keyboard layout: {}", initial.name);
        let km_shared = Arc::new(std::sync::Mutex::new(initial));

        // Follow layout changes (from the settings window) without a restart
        {
            let km_shared = km_shared.clone();
            thread::spawn(move || loop {
                thread::sleep(Duration::from_millis(1000));
                let setting = layout.lock().unwrap().clone();
                let new_km = resolve(&setting);
                let mut cur = km_shared.lock().unwrap();
                if cur.name != new_km.name {
                    eprintln!("Switched keyboard layout to: {}", new_km.name);
                    *cur = new_km;
                }
            });
        }

        let (tx, rx) = mpsc::channel::<(usize, String, bool)>();
        let _ = TYPER.set(std::sync::Mutex::new(tx.clone()));
        super::voice::start_idle_watch();
        super::speak::start_idle_watch();

        // Typing worker: virtual keyboard
        let km_worker = km_shared.clone();
        thread::spawn(move || {
            let mut keys = AttributeSet::<Key>::new();
            for (k, _) in CHARS {
                keys.insert(Key::new(*k));
            }
            // Register the keys of every layout so switching never needs a new device
            for (_, k, _, _) in all_symbols() {
                keys.insert(Key::new(k));
            }
            for k in [SPACE, BACKSPACE, LSHIFT, ALTGR, 29] {
                keys.insert(Key::new(k));
            }
            let built = VirtualDeviceBuilder::new()
                .and_then(|b| b.name(VNAME).with_keys(&keys))
                .and_then(|b| b.build());
            let mut vd = match built {
                Ok(v) => v,
                Err(e) => {
                    eprintln!("Could not create virtual keyboard (check /dev/uinput permissions): {e}");
                    return;
                }
            };
            for (erase, text, trailing_space) in rx {
                let km = *km_worker.lock().unwrap();
                if text == "\u{1}COPY" {
                    // Ctrl+C (left Ctrl = 29, C = 46)
                    let ev = |c: u16, v: i32| InputEvent::new(EventType::KEY, c, v);
                    let _ = vd.emit(&[ev(29, 1)]);
                    tap(&mut vd, 46, false, false);
                    let _ = vd.emit(&[ev(29, 0)]);
                    continue;
                }
                thread::sleep(Duration::from_millis(30));
                for _ in 0..erase {
                    tap(&mut vd, BACKSPACE, false, false);
                }
                for c in text.chars() {
                    match km.keys_of(c) {
                        Some((k, s, a)) => tap(&mut vd, k, s, a),
                        None => eprintln!("Can't type character {c:?} with the {} layout", km.name),
                    }
                }
                if trailing_space {
                    tap(&mut vd, SPACE, false, false);
                }
            }
        });

        // One listener thread per physical keyboard
        let mut found = 0;
        for (_, mut dev) in evdev::enumerate() {
            let is_keyboard = dev
                .supported_keys()
                .map_or(false, |k| k.contains(Key::KEY_A) && k.contains(Key::KEY_SPACE));
            if !is_keyboard || dev.name() == Some(VNAME) {
                continue;
            }
            found += 1;
            let entries = entries.clone();
            let enabled = enabled.clone();
            let tx = tx.clone();
            let km_dev = km_shared.clone();
            let ocr_dev = ocr.clone();
            let voice_dev = voice.clone();
            let speak_dev = speak.clone();
            thread::spawn(move || {
                let mut buffer = String::new();
                let mut shift = 0i32;
                let mut altgr = 0i32;
                let mut ctrl = 0i32;
                let mut alt = 0i32;
                let mut meta = 0i32;
                let mut hk_cache: (String, Option<Hotkey>) = (String::new(), None);
                let mut vk_cache: (String, Option<Hotkey>) = (String::new(), None);
                let mut sk_cache: Vec<(String, Option<Hotkey>)> =
                    (0..4).map(|_| (String::new(), None)).collect();
                let mut last_total_mods = 0i32;
                let mut pending: Option<Pending> = None;
                loop {
                    let events = match dev.fetch_events() {
                        Ok(e) => e,
                        Err(_) => return,
                    };
                    for ev in events {
                        if ev.event_type() != EventType::KEY {
                            continue;
                        }
                        let (code, val) = (ev.code(), ev.value());
                        match code {
                            42 | 54 => bump(&mut shift, val),
                            ALTGR => bump(&mut altgr, val),
                            29 | 97 => bump(&mut ctrl, val),
                            56 => bump(&mut alt, val),
                            125 | 126 => bump(&mut meta, val),
                            _ => {}
                        }
                        let mods = ctrl + alt + meta;
                        let total_mods = shift + altgr + ctrl + alt + meta;
                        if total_mods != last_total_mods {
                            GLOBAL_MODS.fetch_add(total_mods - last_total_mods, Ordering::SeqCst);
                            last_total_mods = total_mods;
                        }
                        let is_modifier = matches!(code, 42 | 54 | ALTGR | 29 | 97 | 56 | 125 | 126);
                        if val == 0 {
                            // Hold-to-talk: letting go of the voice key stops the recording
                            if !is_modifier {
                                let vcfg = voice_dev.lock().unwrap().clone();
                                if vcfg.enabled && vcfg.mode == "hold" {
                                    if vk_cache.0 != vcfg.shortcut {
                                        vk_cache = (vcfg.shortcut.clone(), parse_hotkey(&vcfg.shortcut));
                                    }
                                    let is_voice_key = match &vk_cache.1 {
                                        Some(hk) => hk.key == code,
                                        None => false,
                                    };
                                    if is_voice_key {
                                        thread::spawn(move || super::voice::stop_if_recording(vcfg));
                                    }
                                }
                            }
                            // Wait until the physical trigger key AND any Shift/AltGr/Ctrl
                            // are released before typing, otherwise the system ignores or
                            // changes our virtual key presses.
                            if let Some(p) = pending.as_mut() {
                                if p.key == code {
                                    p.released = true;
                                }
                            }
                            let ready = pending.as_ref().map_or(false, |p| p.released)
                                && shift == 0
                                && altgr == 0
                                && mods == 0;
                            if ready {
                                if let Some(p) = pending.take() {
                                    thread::sleep(Duration::from_millis(20));
                                    let _ = tx.send(p.job);
                                }
                            }
                            continue;
                        }
                        if is_modifier || val != 1 {
                            continue; // only real key presses from here on
                        }
                        // OCR shortcut: checked first, also while expansion is paused
                        {
                            let cfg = ocr_dev.lock().unwrap().clone();
                            if cfg.enabled {
                                if hk_cache.0 != cfg.shortcut {
                                    hk_cache = (cfg.shortcut.clone(), parse_hotkey(&cfg.shortcut));
                                }
                                let hit = match &hk_cache.1 {
                                    Some(hk) => {
                                        code == hk.key
                                            && (ctrl > 0) == hk.ctrl
                                            && (alt > 0) == hk.alt
                                            && (shift > 0) == hk.shift
                                            && (meta > 0) == hk.meta
                                            && altgr == 0
                                    }
                                    None => false,
                                };
                                if hit {
                                    buffer.clear();
                                    pending = None;
                                    thread::spawn(move || super::ocr::run_with_notification(cfg));
                                    continue;
                                }
                            }
                        }
                        // Voice typing shortcut
                        {
                            let vcfg = voice_dev.lock().unwrap().clone();
                            if vcfg.enabled {
                                if vk_cache.0 != vcfg.shortcut {
                                    vk_cache = (vcfg.shortcut.clone(), parse_hotkey(&vcfg.shortcut));
                                }
                                let hit = match &vk_cache.1 {
                                    Some(hk) => {
                                        code == hk.key
                                            && (ctrl > 0) == hk.ctrl
                                            && (alt > 0) == hk.alt
                                            && (shift > 0) == hk.shift
                                            && (meta > 0) == hk.meta
                                            && altgr == 0
                                    }
                                    None => false,
                                };
                                if hit {
                                    buffer.clear();
                                    pending = None;
                                    thread::spawn(move || super::voice::toggle(vcfg));
                                    continue;
                                }
                            }
                        }
                        // Read-aloud shortcuts
                        {
                            let scfg = speak_dev.lock().unwrap().clone();
                            if scfg.enabled {
                                let shortcuts: [String; 4] = [
                                    scfg.read_da.clone(),
                                    scfg.read_en.clone(),
                                    scfg.stop.clone(),
                                    scfg.pause.clone(),
                                ];
                                let actions = ["read-da", "read-en", "read-stop", "read-pause"];
                                let mut fired: Option<&'static str> = None;
                                for i in 0..4 {
                                    if sk_cache[i].0 != shortcuts[i] {
                                        sk_cache[i] = (shortcuts[i].clone(), parse_hotkey(&shortcuts[i]));
                                    }
                                    let hit = match &sk_cache[i].1 {
                                        Some(hk) => {
                                            code == hk.key
                                                && (ctrl > 0) == hk.ctrl
                                                && (alt > 0) == hk.alt
                                                && (shift > 0) == hk.shift
                                                && (meta > 0) == hk.meta
                                                && altgr == 0
                                        }
                                        None => false,
                                    };
                                    if hit {
                                        fired = Some(actions[i]);
                                        break;
                                    }
                                }
                                if let Some(action) = fired {
                                    buffer.clear();
                                    pending = None;
                                    thread::spawn(move || super::speak::run_action(action, scfg));
                                    continue;
                                }
                            }
                        }
                        if !enabled.load(Ordering::SeqCst) || mods > 0 {
                            buffer.clear();
                            pending = None;
                            continue;
                        }
                        if code != SPACE {
                            pending = None;
                        }
                        match code {
                            SPACE => {
                                let hit = entries
                                    .lock()
                                    .unwrap()
                                    .iter()
                                    .find(|e| e.space && e.trigger.to_lowercase() == buffer)
                                    .map(|e| e.text.clone());
                                pending = hit.map(|text| Pending {
                                    key: SPACE,
                                    released: false,
                                    job: (buffer.chars().count() + 1, text, true),
                                });
                                buffer.clear();
                            }
                            BACKSPACE => {
                                buffer.pop();
                            }
                            c => {
                                let km = *km_dev.lock().unwrap();
                                match km.char_of(c, shift > 0, altgr > 0) {
                                    Some(ch) => {
                                        buffer.extend(ch.to_lowercase());
                                        if buffer.chars().count() > 32 {
                                            buffer.clear();
                                        } else {
                                            let hit = entries
                                                .lock()
                                                .unwrap()
                                                .iter()
                                                .find(|e| !e.space && e.trigger.to_lowercase() == buffer)
                                                .map(|e| e.text.clone());
                                            if let Some(text) = hit {
                                                pending = Some(Pending {
                                                    key: code,
                                                    released: false,
                                                    job: (buffer.chars().count(), text, false),
                                                });
                                                buffer.clear();
                                            }
                                        }
                                    }
                                    None => buffer.clear(),
                                }
                            }
                        }
                    }
                }
            });
        }
        if found == 0 {
            eprintln!("No readable keyboards found. Are you in the 'input' group (log out/in after adding)?");
        }
    }
}

// ---------------------------------------------------------------- settings window

#[derive(Clone, Copy, PartialEq)]
enum Tab {
    Expander,
    Ocr,
    Voice,
    Read,
}

struct App {
    entries: Vec<Entry>,
    enabled: bool,
    layout: String,
    lang: Lang,
    running: bool,
    last_check: Instant,
    new_trigger: String,
    new_text: String,
    new_space: bool,
    error: String,
    tab: Tab,
    ocr: OcrConfig,
    recording: bool,
    ocr_hint: String,
    ocr_status: Arc<Mutex<String>>,
    ocr_langs: Vec<String>,
    ocr_reqs: Vec<(String, bool)>,
    ocr_loaded: bool,
    voice: VoiceConfig,
    voice_recording: bool,
    voice_hint: String,
    voice_status: Arc<Mutex<String>>,
    voice_bench: Arc<Mutex<String>>,
    voice_reco: Arc<Mutex<Option<String>>>,
    speak: SpeakConfig,
    speak_recording: Option<usize>,
    speak_hint: String,
    speak_status: Arc<Mutex<String>>,
}

// The command that starts the program from the desktop's own shortcut settings
#[cfg(target_os = "linux")]
fn expander_command() -> String {
    dirs::home_dir()
        .map(|h| h.join(".local/bin/expander").to_string_lossy().to_string())
        .unwrap_or_else(|| "expander".to_string())
}

// Name of a key that can be part of the OCR shortcut (letters, digits, F1-F12)
#[cfg(target_os = "linux")]
fn shortcut_key_name(key: egui::Key) -> Option<String> {
    let name = format!("{:?}", key);
    if name.len() == 1 && name.chars().all(|c| c.is_ascii_uppercase()) {
        return Some(name);
    }
    if let Some(d) = name.strip_prefix("Num") {
        if d.len() == 1 && d.chars().all(|c| c.is_ascii_digit()) {
            return Some(d.to_string());
        }
    }
    if let Some(n) = name.strip_prefix('F') {
        if let Ok(n) = n.parse::<u32>() {
            if (1..=12).contains(&n) {
                return Some(format!("F{}", n));
            }
        }
    }
    None
}

impl App {
    fn add(&mut self) {
        let trigger = self.new_trigger.trim().to_string();
        let text = self.new_text.trim().to_string();
        if trigger.is_empty() || text.is_empty() {
            self.error = tr(self.lang, "Fill in both fields.", "Udfyld begge felter.").into();
            return;
        }
        if trigger.contains(char::is_whitespace) {
            self.error = tr(
                self.lang,
                "A trigger can't contain spaces.",
                "En genvej må ikke indeholde mellemrum.",
            )
            .into();
            return;
        }
        if let Some(existing) = self
            .entries
            .iter_mut()
            .find(|e| e.trigger.to_lowercase() == trigger.to_lowercase())
        {
            existing.text = text;
            existing.space = self.new_space;
        } else {
            self.entries.push(Entry {
                trigger,
                text,
                space: self.new_space,
            });
        }
        save(&self.entries);
        self.new_trigger.clear();
        self.new_text.clear();
        self.error.clear();
    }

    // ---- tab 1: the text expander
    fn ui_expander(&mut self, ui: &mut egui::Ui, lang: Lang) {
        if ui
            .checkbox(&mut self.enabled, tr(lang, "Expansion enabled", "Udvidelse aktiveret"))
            .changed()
        {
            set_enabled(self.enabled);
        }

        // Keyboard layout (Linux only: Windows and macOS handle layouts themselves)
        if cfg!(target_os = "linux") {
            let layouts = [
                ("auto", "Auto (from KDE settings)", "Auto (fra KDE-indstillinger)"),
                ("dk", "Danish", "Dansk"),
                ("us", "English (US)", "Engelsk (US)"),
                ("uk", "English (UK)", "Engelsk (UK)"),
                ("fi", "Finnish / Swedish", "Finsk / Svensk"),
            ];
            let current_label = layouts
                .iter()
                .find(|&&(k, _, _)| k == self.layout)
                .map(|&(_, en, da)| tr(lang, en, da))
                .unwrap_or(tr(lang, "Auto (from KDE settings)", "Auto (fra KDE-indstillinger)"));
            ui.horizontal(|ui| {
                ui.label(tr(lang, "Keyboard layout:", "Tastaturlayout:"));
                egui::ComboBox::from_id_salt("layout")
                    .selected_text(current_label)
                    .show_ui(ui, |ui| {
                        for (code, en, da) in layouts {
                            if ui
                                .selectable_value(&mut self.layout, code.to_string(), tr(lang, en, da))
                                .changed()
                            {
                                save_layout(&self.layout);
                            }
                        }
                    });
            });
        }
        ui.separator();

        ui.horizontal(|ui| {
            ui.add(
                egui::TextEdit::singleline(&mut self.new_trigger)
                    .hint_text(tr(lang, "Trigger (e.g. omy)", "Genvej (fx omy)"))
                    .desired_width(120.0),
            );
            let resp = ui.add(
                egui::TextEdit::singleline(&mut self.new_text)
                    .hint_text(tr(lang, "Expands to (e.g. on my way)", "Bliver til (fx er på vej)"))
                    .desired_width(220.0),
            );
            ui.checkbox(&mut self.new_space, tr(lang, "Needs Space", "Kræver mellemrum"));
            let enter = resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
            if ui.button(tr(lang, "Add", "Tilføj")).clicked() || enter {
                self.add();
            }
        });
        ui.label(tr(
            lang,
            "Needs Space on: type the trigger, then press Space. Off: it expands instantly as soon as the trigger is typed.",
            "Kræver mellemrum slået til: skriv genvejen og tryk på mellemrum. Slået fra: den udvides med det samme, når genvejen er skrevet.",
        ));
        if !self.error.is_empty() {
            ui.colored_label(egui::Color32::LIGHT_RED, &self.error);
        }
        ui.separator();

        let mut remove: Option<usize> = None;
        let mut changed = false;
        egui::ScrollArea::vertical().show(ui, |ui| {
            egui::Grid::new("triggers")
                .striped(true)
                .num_columns(4)
                .spacing([16.0, 6.0])
                .show(ui, |ui| {
                    ui.strong(tr(lang, "Trigger", "Genvej"));
                    ui.strong(tr(lang, "Expands to", "Bliver til"));
                    ui.strong(tr(lang, "Needs Space", "Kræver mellemrum"));
                    ui.label("");
                    ui.end_row();
                    for (i, e) in self.entries.iter_mut().enumerate() {
                        ui.monospace(&e.trigger);
                        ui.label(&e.text);
                        if ui.checkbox(&mut e.space, "").changed() {
                            changed = true;
                        }
                        if ui.button(tr(lang, "Delete", "Slet")).clicked() {
                            remove = Some(i);
                        }
                        ui.end_row();
                    }
                });
        });
        if changed {
            save(&self.entries);
        }
        if let Some(i) = remove {
            self.entries.remove(i);
            save(&self.entries);
        }
    }

    // ---- tab 2: OCR (Linux)
    #[cfg(target_os = "linux")]
    fn refresh_ocr_info(&mut self) {
        self.ocr_langs = ocr::installed_languages();
        self.ocr_reqs = ocr::requirements();
        self.ocr_loaded = true;
    }

    #[cfg(target_os = "linux")]
    fn ui_ocr(&mut self, ui: &mut egui::Ui, lang: Lang) {
        if !self.ocr_loaded {
            self.refresh_ocr_info();
        }
        ui.label(tr(
            lang,
            "Press the shortcut, select an area of the screen, and the text in it is copied to the clipboard.",
            "Tryk på genvejen, markér et område på skærmen, og teksten i det kopieres til udklipsholderen.",
        ));
        ui.add_space(6.0);

        if ui
            .checkbox(&mut self.ocr.enabled, tr(lang, "OCR shortcut enabled", "OCR-genvej aktiveret"))
            .changed()
        {
            save_ocr(&self.ocr);
        }

        // Recording a new shortcut: the next key combination is taken
        if self.recording {
            let events = ui.input(|i| i.events.clone());
            for ev in events {
                if let egui::Event::Key { key, pressed: true, modifiers, .. } = ev {
                    if key == egui::Key::Escape {
                        self.recording = false;
                        break;
                    }
                    if let Some(name) = shortcut_key_name(key) {
                        if modifiers.ctrl || modifiers.alt || (name.starts_with('F') && name.len() > 1) {
                            let mut parts: Vec<String> = Vec::new();
                            if modifiers.ctrl {
                                parts.push("Ctrl".to_string());
                            }
                            if modifiers.alt {
                                parts.push("Alt".to_string());
                            }
                            if modifiers.shift {
                                parts.push("Shift".to_string());
                            }
                            parts.push(name);
                            self.ocr.shortcut = parts.join("+");
                            save_ocr(&self.ocr);
                            self.recording = false;
                            self.ocr_hint.clear();
                            break;
                        } else {
                            self.ocr_hint = tr(
                                lang,
                                "Use Ctrl or Alt together with a key, or a function key such as F9.",
                                "Brug Ctrl eller Alt sammen med en tast, eller en funktionstast som F9.",
                            )
                            .to_string();
                        }
                    }
                }
            }
        }

        ui.horizontal(|ui| {
            ui.label(tr(lang, "Shortcut:", "Genvej:"));
            if self.recording {
                ui.strong(tr(
                    lang,
                    "Press the new shortcut now (Esc cancels)",
                    "Tryk på den nye genvej nu (Esc annullerer)",
                ));
                if ui.button(tr(lang, "Cancel", "Annuller")).clicked() {
                    self.recording = false;
                }
            } else {
                ui.monospace(self.ocr.shortcut.clone());
                if ui.button(tr(lang, "Change...", "Skift...")).clicked() {
                    self.recording = true;
                    self.ocr_hint.clear();
                }
            }
        });
        if !self.ocr_hint.is_empty() {
            ui.colored_label(egui::Color32::LIGHT_RED, &self.ocr_hint);
        }
        ui.label(tr(
            lang,
            "If the shortcut types a letter into your document, use a key that types nothing (like F10), or let KDE handle the shortcut: System Settings > Keyboard > Shortcuts > Add Command, with this command:",
            "Hvis genvejen skriver et bogstav i dit dokument, så brug en tast, der intet skriver (fx F10), eller lad KDE styre genvejen: Systemindstillinger > Tastatur > Genveje > Tilføj kommando, med denne kommando:",
        ));
        ui.monospace(format!("{} --ocr", expander_command()));
        ui.label(tr(
            lang,
            "Pick a combination that no other program uses, for example Ctrl+Alt+O.",
            "Vælg en kombination, som intet andet program bruger, fx Ctrl+Alt+O.",
        ));
        ui.add_space(6.0);

        ui.horizontal(|ui| {
            ui.label(tr(lang, "Text language(s):", "Tekstsprog:"));
            if ui
                .add(egui::TextEdit::singleline(&mut self.ocr.languages).desired_width(140.0))
                .changed()
            {
                save_ocr(&self.ocr);
            }
            ui.label(tr(lang, "e.g. eng+dan", "fx eng+dan"));
        });
        let langs_text = if self.ocr_langs.is_empty() {
            tr(lang, "none found", "ingen fundet").to_string()
        } else {
            self.ocr_langs.join(", ")
        };
        ui.label(format!(
            "{} {}",
            tr(lang, "Installed languages:", "Installerede sprog:"),
            langs_text
        ));
        ui.add_space(6.0);

        if ui.button(tr(lang, "Try OCR now", "Prøv OCR nu")).clicked() {
            let status = self.ocr_status.clone();
            let cfg = self.ocr.clone();
            *status.lock().unwrap() =
                tr(lang, "Select an area on the screen...", "Markér et område på skærmen...").to_string();
            thread::spawn(move || {
                let msg = match ocr::run_once(cfg) {
                    Ok(text) => {
                        let preview: String = text.chars().take(200).collect();
                        format!(
                            "{} {}: {}",
                            tr(lang, "Copied characters:", "Kopierede tegn:"),
                            text.chars().count(),
                            preview
                        )
                    }
                    Err(e) if e.is_empty() => tr(lang, "Cancelled.", "Annulleret.").to_string(),
                    Err(e) => format!("{} {}", tr(lang, "Error:", "Fejl:"), e),
                };
                *status.lock().unwrap() = msg;
            });
        }
        let status_text = self.ocr_status.lock().unwrap().clone();
        if !status_text.is_empty() {
            ui.label(status_text);
        }

        ui.separator();
        ui.horizontal(|ui| {
            ui.strong(tr(lang, "Requirements", "Krav"));
            if ui.button(tr(lang, "Check again", "Tjek igen")).clicked() {
                self.refresh_ocr_info();
            }
        });
        let mut missing = self.ocr_langs.is_empty();
        for (name, ok) in self.ocr_reqs.clone() {
            if ok {
                ui.colored_label(egui::Color32::LIGHT_GREEN, format!("OK: {}", name));
            } else {
                missing = true;
                ui.colored_label(egui::Color32::LIGHT_RED, format!("Missing: {}", name));
            }
        }
        if missing {
            ui.label(tr(lang, "Install on Fedora:", "Installér på Fedora:"));
            ui.monospace("sudo dnf install tesseract tesseract-langpack-dan wl-clipboard xclip");
        }
    }

    // ---- tab 3: voice typing (Linux)
    #[cfg(target_os = "linux")]
    fn ui_voice(&mut self, ui: &mut egui::Ui, lang: Lang) {
        egui::ScrollArea::vertical().show(ui, |ui| {
            ui.label(tr(
                lang,
                "Press the shortcut, speak, and the text is typed where your cursor is. Everything runs on this computer.",
                "Tryk på genvejen, tal, og teksten skrives, hvor din markør er. Alt kører på denne computer.",
            ));
            ui.add_space(6.0);

            if ui
                .checkbox(&mut self.voice.enabled, tr(lang, "Voice typing enabled", "Tale til tekst aktiveret"))
                .changed()
            {
                save_voice(&self.voice);
            }

            // Recording a new shortcut
            if self.voice_recording {
                let events = ui.input(|i| i.events.clone());
                for ev in events {
                    if let egui::Event::Key { key, pressed: true, modifiers, .. } = ev {
                        if key == egui::Key::Escape {
                            self.voice_recording = false;
                            break;
                        }
                        if let Some(name) = shortcut_key_name(key) {
                            if modifiers.ctrl || modifiers.alt || (name.starts_with('F') && name.len() > 1) {
                                let mut parts: Vec<String> = Vec::new();
                                if modifiers.ctrl {
                                    parts.push("Ctrl".to_string());
                                }
                                if modifiers.alt {
                                    parts.push("Alt".to_string());
                                }
                                if modifiers.shift {
                                    parts.push("Shift".to_string());
                                }
                                parts.push(name);
                                self.voice.shortcut = parts.join("+");
                                save_voice(&self.voice);
                                self.voice_recording = false;
                                self.voice_hint.clear();
                                break;
                            } else {
                                self.voice_hint = tr(
                                    lang,
                                    "Use Ctrl or Alt together with a key, or a function key such as F9.",
                                    "Brug Ctrl eller Alt sammen med en tast, eller en funktionstast som F9.",
                                )
                                .to_string();
                            }
                        }
                    }
                }
            }
            ui.horizontal(|ui| {
                ui.label(tr(lang, "Shortcut:", "Genvej:"));
                if self.voice_recording {
                    ui.strong(tr(
                        lang,
                        "Press the new shortcut now (Esc cancels)",
                        "Tryk på den nye genvej nu (Esc annullerer)",
                    ));
                    if ui.button(tr(lang, "Cancel", "Annuller")).clicked() {
                        self.voice_recording = false;
                    }
                } else {
                    ui.monospace(self.voice.shortcut.clone());
                    if ui.button(tr(lang, "Change...", "Skift...")).clicked() {
                        self.voice_recording = true;
                        self.voice_hint.clear();
                    }
                }
            });
            if !self.voice_hint.is_empty() {
                ui.colored_label(egui::Color32::LIGHT_RED, &self.voice_hint);
            }
            ui.label(tr(
                lang,
                "If the shortcut types a letter into your document, use a key that types nothing (like F9), or let KDE handle the shortcut: System Settings > Keyboard > Shortcuts > Add Command, with this command:",
                "Hvis genvejen skriver et bogstav i dit dokument, så brug en tast, der intet skriver (fx F9), eller lad KDE styre genvejen: Systemindstillinger > Tastatur > Genveje > Tilføj kommando, med denne kommando:",
            ));
            ui.monospace(format!("{} --voice-toggle", expander_command()));

            // Mode
            let modes = [
                ("toggle", "Press once to start, again to stop", "Tryk én gang for at starte, igen for at stoppe"),
                ("hold", "Hold the keys while speaking", "Hold tasterne nede, mens du taler"),
            ];
            let mode_label = modes
                .iter()
                .find(|&&(k, _, _)| k == self.voice.mode)
                .map(|&(_, en, da)| tr(lang, en, da))
                .unwrap_or("");
            ui.horizontal(|ui| {
                ui.label(tr(lang, "Mode:", "Tilstand:"));
                egui::ComboBox::from_id_salt("voice_mode")
                    .selected_text(mode_label)
                    .show_ui(ui, |ui| {
                        for (code, en, da) in modes {
                            if ui
                                .selectable_value(&mut self.voice.mode, code.to_string(), tr(lang, en, da))
                                .changed()
                            {
                                save_voice(&self.voice);
                            }
                        }
                    });
            });

            // Spoken language
            let languages = [
                ("da", "Danish", "Dansk"),
                ("en", "English", "Engelsk"),
                ("auto", "Detect automatically", "Find automatisk"),
            ];
            let language_label = languages
                .iter()
                .find(|&&(k, _, _)| k == self.voice.language)
                .map(|&(_, en, da)| tr(lang, en, da))
                .unwrap_or("");
            ui.horizontal(|ui| {
                ui.label(tr(lang, "Spoken language:", "Talt sprog:"));
                egui::ComboBox::from_id_salt("voice_language")
                    .selected_text(language_label)
                    .show_ui(ui, |ui| {
                        for (code, en, da) in languages {
                            if ui
                                .selectable_value(&mut self.voice.language, code.to_string(), tr(lang, en, da))
                                .changed()
                            {
                                save_voice(&self.voice);
                            }
                        }
                    });
            });

            ui.label(tr(
                lang,
                "The language setting is used by the Whisper models. Parakeet detects Danish and English by itself.",
                "Sprogvalget bruges af Whisper-modellerne. Parakeet finder selv ud af, om det er dansk eller engelsk.",
            ));

            // Live text while speaking
            ui.separator();
            if ui
                .checkbox(
                    &mut self.voice.live,
                    tr(
                        lang,
                        "Show what I say on the screen while I speak",
                        "Vis, hvad jeg siger, på skærmen, mens jeg taler",
                    ),
                )
                .changed()
            {
                save_voice(&self.voice);
            }
            if self.voice.live {
                let styles = [
                    ("box", "Box on the screen", "Boks på skærmen"),
                    ("notification", "Desktop notification (never takes focus)", "Skrivebordsbesked (tager aldrig fokus)"),
                ];
                let style_label = styles
                    .iter()
                    .find(|&&(k, _, _)| k == self.voice.live_style)
                    .map(|&(_, en, da)| tr(lang, en, da))
                    .unwrap_or("");
                ui.horizontal(|ui| {
                    ui.label(tr(lang, "Show it as:", "Vis som:"));
                    egui::ComboBox::from_id_salt("voice_style")
                        .selected_text(style_label)
                        .show_ui(ui, |ui| {
                            for (code, en, da) in styles {
                                if ui
                                    .selectable_value(&mut self.voice.live_style, code.to_string(), tr(lang, en, da))
                                    .changed()
                                {
                                    save_voice(&self.voice);
                                }
                            }
                        });
                });

                ui.label(tr(
                    lang,
                    "The text appears after each pause in your speech.",
                    "Teksten vises efter hver pause i din tale.",
                ));
            }

            // Behaviour
            ui.separator();
            ui.strong(tr(lang, "Behaviour", "Opførsel"));
            if ui
                .checkbox(
                    &mut self.voice.sounds,
                    tr(
                        lang,
                        "Play a sound when listening starts and stops",
                        "Afspil en lyd, når optagelsen starter og stopper",
                    ),
                )
                .changed()
            {
                save_voice(&self.voice);
            }
            if ui
                .button(tr(lang, "Play test sound", "Afspil testlyd"))
                .clicked()
            {
                let status = self.voice_status.clone();
                thread::spawn(move || {
                    let msg = match voice::test_sound() {
                        Ok(tool) => format!("{} {}.", tr(lang, "Sound played with", "Lyd afspillet med"), tool),
                        Err(e) => format!("{} {}", tr(lang, "Sound failed:", "Lyd fejlede:"), e),
                    };
                    *status.lock().unwrap() = msg;
                });
            }
            if ui
                .checkbox(
                    &mut self.voice.review,
                    tr(
                        lang,
                        "Show the text in a box I can correct before it is typed (Enter sends it)",
                        "Vis teksten i en boks, jeg kan rette i, før den skrives (Enter sender den)",
                    ),
                )
                .changed()
            {
                save_voice(&self.voice);
            }
            if ui
                .checkbox(
                    &mut self.voice.type_live,
                    tr(
                        lang,
                        "Type each phrase as soon as I pause (press once to start, again to stop)",
                        "Skriv hver sætning, så snart jeg holder pause (tryk én gang for at starte, igen for at stoppe)",
                    ),
                )
                .changed()
            {
                save_voice(&self.voice);
            }
            ui.horizontal(|ui| {
                ui.label(tr(
                    lang,
                    "A pause this long ends a phrase:",
                    "En pause af denne længde afslutter en sætning:",
                ));
                if ui
                    .add(egui::Slider::new(&mut self.voice.pause_ms, 250..=1500).suffix(" ms"))
                    .changed()
                {
                    save_voice(&self.voice);
                }
            });

            // Models
            ui.separator();
            ui.strong(tr(lang, "Models (download the ones you want to use)", "Modeller (hent dem, du vil bruge)"));
            ui.label(tr(
                lang,
                "Parakeet is the fastest choice. Bigger Whisper models can be more accurate but are much slower and need more memory. Pick the one that fits this computer.",
                "Parakeet er det hurtigste valg. Større Whisper-modeller kan være mere præcise, men er meget langsommere og bruger mere hukommelse. Vælg den, der passer til denne computer.",
            ));
            let dl = voice::download_snapshot();
            let mut action: Option<(&'static str, char)> = None;
            egui::Grid::new("voice_models")
                .striped(true)
                .num_columns(5)
                .spacing([12.0, 6.0])
                .show(ui, |ui| {
                    for m in voice::MODELS {
                        let ready = voice::model_ready(m.id);
                        let selected = self.voice.model == m.id;
                        if ui.radio(selected, "").clicked() && ready {
                            self.voice.model = m.id.to_string();
                            save_voice(&self.voice);
                        }
                        ui.label(tr(lang, m.label_en, m.label_da));
                        ui.label(format!("~{} MB", m.mb));
                        let downloading_this = matches!(&dl, Some((id, true, _)) if id == m.id);
                        if downloading_this {
                            let done = voice::download_bytes(m.id) as f64;
                            let pct = (done / (m.mb as f64 * 1_000_000.0) * 100.0).min(99.0);
                            ui.label(format!("{} {:.0}%", tr(lang, "Downloading", "Henter"), pct));
                            if ui.button(tr(lang, "Cancel", "Annuller")).clicked() {
                                action = Some((m.id, 'c'));
                            }
                        } else if ready {
                            ui.colored_label(egui::Color32::LIGHT_GREEN, tr(lang, "Downloaded", "Hentet"));
                            if ui.button(tr(lang, "Delete", "Slet")).clicked() {
                                action = Some((m.id, 'x'));
                            }
                        } else {
                            ui.label(tr(lang, "Not downloaded", "Ikke hentet"));
                            if ui.button(tr(lang, "Download", "Hent")).clicked() {
                                action = Some((m.id, 'd'));
                            }
                        }
                        ui.end_row();
                    }
                });
            match action {
                Some((id, 'd')) => voice::start_download(id),
                Some((_, 'c')) => voice::cancel_download(),
                Some((id, 'x')) => voice::delete_model(id),
                _ => {}
            }
            if let Some((id, false, err)) = &dl {
                if !err.is_empty() {
                    ui.colored_label(egui::Color32::LIGHT_RED, format!("{}: {}", id, err));
                }
            }
            ui.label(format!(
                "{} {}",
                tr(lang, "Models are stored in:", "Modellerne gemmes i:"),
                voice::models_dir().display()
            ));

            // Best model for this computer
            ui.separator();
            ui.strong(tr(lang, "Best model for this computer", "Bedste model til denne computer"));
            let hw = voice::hardware();
            ui.label(format!(
                "{}  |  {} {}  |  {} MB RAM",
                hw.cpu,
                hw.cores,
                tr(lang, "cores", "kerner"),
                hw.ram_mb
            ));
            let suggested = voice::suggested_model(&hw);
            let suggested_label = voice::MODELS
                .iter()
                .find(|m| m.id == suggested)
                .map(|m| tr(lang, m.label_en, m.label_da))
                .unwrap_or("");
            ui.label(format!(
                "{} {}",
                tr(lang, "Suggestion from the hardware:", "Forslag ud fra hardwaren:"),
                suggested_label
            ));
            ui.label(tr(
                lang,
                "For an exact answer: download a few models above, then run the speed test. It reads the same 5 seconds of your speech with every downloaded model and tells you which one is fast enough.",
                "For et præcist svar: hent et par modeller ovenfor og kør hastighedstesten. Den aflæser de samme 5 sekunders tale med hver hentet model og fortæller, hvilken der er hurtig nok.",
            ));
            if ui
                .button(tr(lang, "Run speed test (speak for 5 seconds)", "Kør hastighedstest (tal i 5 sekunder)"))
                .clicked()
            {
                let bench = self.voice_bench.clone();
                let reco = self.voice_reco.clone();
                let cfg = self.voice.clone();
                *bench.lock().unwrap() = tr(lang, "Starting...", "Starter...").to_string();
                *reco.lock().unwrap() = None;
                thread::spawn(move || match voice::benchmark(cfg, bench.clone()) {
                    Ok((text, best)) => {
                        *bench.lock().unwrap() = text;
                        *reco.lock().unwrap() = best;
                    }
                    Err(e) => {
                        *bench.lock().unwrap() = format!("{} {}", tr(lang, "Error:", "Fejl:"), e);
                    }
                });
            }
            let bench_text = self.voice_bench.lock().unwrap().clone();
            if !bench_text.is_empty() {
                ui.monospace(bench_text);
            }
            let best = self.voice_reco.lock().unwrap().clone();
            if let Some(id) = best {
                let label = voice::MODELS
                    .iter()
                    .find(|m| m.id == id)
                    .map(|m| tr(lang, m.label_en, m.label_da))
                    .unwrap_or("");
                ui.horizontal(|ui| {
                    ui.label(format!(
                        "{} {}",
                        tr(lang, "Best for this computer:", "Bedst til denne computer:"),
                        label
                    ));
                    if ui.button(tr(lang, "Use this model", "Brug denne model")).clicked() {
                        self.voice.model = id.clone();
                        save_voice(&self.voice);
                    }
                });
            }

            // Test
            ui.separator();
            if ui
                .button(tr(lang, "Test: record 5 seconds", "Test: optag 5 sekunder"))
                .clicked()
            {
                let status = self.voice_status.clone();
                let cfg = self.voice.clone();
                *status.lock().unwrap() = tr(
                    lang,
                    "Recording for 5 seconds - speak now...",
                    "Optager i 5 sekunder - tal nu...",
                )
                .to_string();
                thread::spawn(move || {
                    let msg = match voice::test_once(cfg, 5) {
                        Ok(t) if t.is_empty() => tr(lang, "No speech detected.", "Ingen tale registreret.").to_string(),
                        Ok(t) => format!("{} {}", tr(lang, "Heard:", "Hørte:"), t),
                        Err(e) => format!("{} {}", tr(lang, "Error:", "Fejl:"), e),
                    };
                    *status.lock().unwrap() = msg;
                });
            }
            let status_text = self.voice_status.lock().unwrap().clone();
            if !status_text.is_empty() {
                ui.label(status_text);
            }
            let stats_text = voice::read_stats();
            if !stats_text.is_empty() {
                ui.label(tr(
                    lang,
                    "Latest readings by the background service (how long each took):",
                    "Seneste aflæsninger fra baggrundstjenesten (hvor lang tid hver tog):",
                ));
                ui.monospace(stats_text);
            }

            // Requirements
            ui.separator();
            ui.strong(tr(lang, "Requirements", "Krav"));
            for (name, ok) in voice::requirements(&self.voice.model) {
                if ok {
                    ui.colored_label(egui::Color32::LIGHT_GREEN, format!("OK: {}", name));
                } else {
                    ui.colored_label(egui::Color32::LIGHT_RED, format!("Missing: {}", name));
                }
            }
        });
    }

    // ---- tab 4: read aloud (Linux)
    #[cfg(target_os = "linux")]
    fn ui_read(&mut self, ui: &mut egui::Ui, lang: Lang) {
        egui::ScrollArea::vertical().show(ui, |ui| {
            ui.label(tr(
                lang,
                "Select text in any program, press a shortcut, and it is read aloud. Everything runs on this computer.",
                "Markér tekst i et vilkårligt program, tryk på en genvej, og den læses højt. Alt kører på denne computer.",
            ));
            ui.add_space(6.0);

            if ui
                .checkbox(&mut self.speak.enabled, tr(lang, "Read-aloud shortcuts enabled", "Oplæsningsgenveje aktiveret"))
                .changed()
            {
                save_speak(&self.speak);
            }

            // Recording a new shortcut for one of the four actions
            if let Some(index) = self.speak_recording {
                let events = ui.input(|i| i.events.clone());
                for ev in events {
                    if let egui::Event::Key { key, pressed: true, modifiers, .. } = ev {
                        if key == egui::Key::Escape {
                            self.speak_recording = None;
                            break;
                        }
                        if let Some(name) = shortcut_key_name(key) {
                            if modifiers.ctrl || modifiers.alt || (name.starts_with('F') && name.len() > 1) {
                                let mut parts: Vec<String> = Vec::new();
                                if modifiers.ctrl {
                                    parts.push("Ctrl".to_string());
                                }
                                if modifiers.alt {
                                    parts.push("Alt".to_string());
                                }
                                if modifiers.shift {
                                    parts.push("Shift".to_string());
                                }
                                parts.push(name);
                                let combo = parts.join("+");
                                match index {
                                    0 => self.speak.read_da = combo,
                                    1 => self.speak.read_en = combo,
                                    2 => self.speak.stop = combo,
                                    _ => self.speak.pause = combo,
                                }
                                save_speak(&self.speak);
                                self.speak_recording = None;
                                self.speak_hint.clear();
                                break;
                            } else {
                                self.speak_hint = tr(
                                    lang,
                                    "Use Ctrl or Alt together with a key, or a function key such as F9.",
                                    "Brug Ctrl eller Alt sammen med en tast, eller en funktionstast som F9.",
                                )
                                .to_string();
                            }
                        }
                    }
                }
            }

            let rows = [
                (0usize, tr(lang, "Read the selected text in Danish:", "Læs den markerede tekst op på dansk:"), self.speak.read_da.clone()),
                (1usize, tr(lang, "Read the selected text in English:", "Læs den markerede tekst op på engelsk:"), self.speak.read_en.clone()),
                (2usize, tr(lang, "Stop reading:", "Stop oplæsning:"), self.speak.stop.clone()),
                (3usize, tr(lang, "Pause / resume:", "Pause / fortsæt:"), self.speak.pause.clone()),
            ];
            for (index, label, shortcut) in rows {
                ui.horizontal(|ui| {
                    ui.label(label);
                    if self.speak_recording == Some(index) {
                        ui.strong(tr(lang, "Press the new shortcut (Esc cancels)", "Tryk på den nye genvej (Esc annullerer)"));
                        if ui.button(tr(lang, "Cancel", "Annuller")).clicked() {
                            self.speak_recording = None;
                        }
                    } else {
                        ui.monospace(shortcut);
                        if ui.button(tr(lang, "Change...", "Skift...")).clicked() {
                            self.speak_recording = Some(index);
                            self.speak_hint.clear();
                        }
                    }
                });
            }
            if !self.speak_hint.is_empty() {
                ui.colored_label(egui::Color32::LIGHT_RED, &self.speak_hint);
            }

            ui.add_space(4.0);
            ui.label(tr(
                lang,
                "If a shortcut types a letter into your document, use a key that types nothing (like F6), or let KDE handle the shortcuts: System Settings > Keyboard > Shortcuts > Add Command, with these commands:",
                "Hvis en genvej skriver et bogstav i dit dokument, så brug en tast, der intet skriver (fx F6), eller lad KDE styre genvejene: Systemindstillinger > Tastatur > Genveje > Tilføj kommando, med disse kommandoer:",
            ));
            for flag in ["--read-da", "--read-en", "--read-stop", "--read-pause"] {
                ui.monospace(format!("{} {}", expander_command(), flag));
            }

            ui.separator();
            ui.horizontal(|ui| {
                ui.label(tr(lang, "Reading speed:", "Oplæsningshastighed:"));
                if ui
                    .add(egui::Slider::new(&mut self.speak.speed, 0.6..=1.6).suffix("x"))
                    .changed()
                {
                    save_speak(&self.speak);
                }
            });

            // Voices
            ui.separator();
            ui.strong(tr(lang, "Voices (download the ones you want)", "Stemmer (hent dem, du vil bruge)"));
            ui.label(tr(
                lang,
                "Choose one voice for Danish and one for English with the round buttons.",
                "Vælg én stemme til dansk og én til engelsk med de runde knapper.",
            ));
            let dl = speak::download_snapshot();
            let mut action: Option<(&'static str, char)> = None;
            egui::Grid::new("speak_voices")
                .striped(true)
                .num_columns(5)
                .spacing([12.0, 6.0])
                .show(ui, |ui| {
                    for v in speak::VOICES {
                        let ready = speak::voice_ready(v.id);
                        let selected = if v.lang == "da" {
                            self.speak.voice_da == v.id
                        } else {
                            self.speak.voice_en == v.id
                        };
                        if ui.radio(selected, "").clicked() && ready {
                            if v.lang == "da" {
                                self.speak.voice_da = v.id.to_string();
                            } else {
                                self.speak.voice_en = v.id.to_string();
                            }
                            save_speak(&self.speak);
                        }
                        ui.label(tr(lang, v.label_en, v.label_da));
                        ui.label(format!("~{} MB", v.mb));
                        let downloading_this = matches!(&dl, Some((id, true, _)) if id == v.id);
                        if downloading_this {
                            let done = speak::download_bytes(v.id) as f64;
                            let pct = (done / (v.mb as f64 * 1_000_000.0) * 100.0).min(99.0);
                            ui.label(format!("{} {:.0}%", tr(lang, "Downloading", "Henter"), pct));
                            if ui.button(tr(lang, "Cancel", "Annuller")).clicked() {
                                action = Some((v.id, 'c'));
                            }
                        } else if ready {
                            ui.colored_label(egui::Color32::LIGHT_GREEN, tr(lang, "Downloaded", "Hentet"));
                            if ui.button(tr(lang, "Delete", "Slet")).clicked() {
                                action = Some((v.id, 'x'));
                            }
                        } else {
                            ui.label(tr(lang, "Not downloaded", "Ikke hentet"));
                            if ui.button(tr(lang, "Download", "Hent")).clicked() {
                                action = Some((v.id, 'd'));
                            }
                        }
                        ui.end_row();
                    }
                });
            match action {
                Some((id, 'd')) => speak::start_download(id),
                Some((_, 'c')) => speak::cancel_download(),
                Some((id, 'x')) => speak::delete_voice(id),
                _ => {}
            }
            if let Some((id, false, err)) = &dl {
                if !err.is_empty() {
                    ui.colored_label(egui::Color32::LIGHT_RED, format!("{}: {}", id, err));
                }
            }

            // Test
            ui.separator();
            ui.horizontal(|ui| {
                if ui.button(tr(lang, "Test Danish voice", "Test dansk stemme")).clicked() {
                    let status = self.speak_status.clone();
                    let cfg = self.speak.clone();
                    *status.lock().unwrap() = tr(lang, "Reading...", "Læser op...").to_string();
                    thread::spawn(move || {
                        let msg = match speak::say_test(cfg, "da") {
                            Ok(()) => String::new(),
                            Err(e) => format!("{} {}", tr(lang, "Error:", "Fejl:"), e),
                        };
                        *status.lock().unwrap() = msg;
                    });
                }
                if ui.button(tr(lang, "Test English voice", "Test engelsk stemme")).clicked() {
                    let status = self.speak_status.clone();
                    let cfg = self.speak.clone();
                    *status.lock().unwrap() = tr(lang, "Reading...", "Læser op...").to_string();
                    thread::spawn(move || {
                        let msg = match speak::say_test(cfg, "en") {
                            Ok(()) => String::new(),
                            Err(e) => format!("{} {}", tr(lang, "Error:", "Fejl:"), e),
                        };
                        *status.lock().unwrap() = msg;
                    });
                }
                if ui.button(tr(lang, "Stop", "Stop")).clicked() {
                    speak::stop();
                }
            });
            let status_text = self.speak_status.lock().unwrap().clone();
            if !status_text.is_empty() {
                ui.label(status_text);
            }

            // Requirements
            ui.separator();
            ui.strong(tr(lang, "Requirements", "Krav"));
            for (name, ok) in speak::requirements() {
                if ok {
                    ui.colored_label(egui::Color32::LIGHT_GREEN, format!("OK: {}", name));
                } else {
                    ui.colored_label(egui::Color32::LIGHT_RED, format!("Missing: {}", name));
                }
            }
        });
    }

    // OCR is only available on Linux for now
    #[cfg(not(target_os = "linux"))]
    fn ui_ocr(&mut self, _ui: &mut egui::Ui, _lang: Lang) {}

    #[cfg(not(target_os = "linux"))]
    fn ui_voice(&mut self, _ui: &mut egui::Ui, _lang: Lang) {}

    #[cfg(not(target_os = "linux"))]
    fn ui_read(&mut self, _ui: &mut egui::Ui, _lang: Lang) {}
}

impl eframe::App for App {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        let lang = self.lang;
        // faster refresh while a model is downloading (progress)
        #[cfg(target_os = "linux")]
        if matches!(voice::download_snapshot(), Some((_, true, _)))
            || matches!(speak::download_snapshot(), Some((_, true, _)))
        {
            ctx.request_repaint_after(Duration::from_millis(500));
        }
        if self.last_check.elapsed() > Duration::from_secs(2) {
            self.running = daemon_running();
            self.last_check = Instant::now();
        }
        ctx.request_repaint_after(Duration::from_secs(2));

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading(format!("Text Expander  v{}", env!("CARGO_PKG_VERSION")));

            ui.horizontal(|ui| {
                if self.running {
                    ui.colored_label(
                        egui::Color32::LIGHT_GREEN,
                        tr(lang, "Running in the background", "Kører i baggrunden"),
                    );
                    if ui.button(tr(lang, "Stop", "Stop")).clicked() {
                        stop_daemon();
                        self.running = false;
                    }
                } else {
                    ui.colored_label(egui::Color32::LIGHT_RED, tr(lang, "Not running", "Kører ikke"));
                    if ui.button(tr(lang, "Start", "Start")).clicked() {
                        start_daemon();
                        thread::sleep(Duration::from_millis(400));
                        self.running = daemon_running();
                    }
                }
            });
            ui.label(tr(
                lang,
                "You can close this window; everything keeps working in the background.",
                "Du kan lukke dette vindue; alt kører videre i baggrunden.",
            ));

            // Interface language
            ui.horizontal(|ui| {
                ui.label(tr(lang, "Language:", "Sprog:"));
                egui::ComboBox::from_id_salt("lang")
                    .selected_text(if lang == Lang::Da { "Dansk" } else { "English" })
                    .show_ui(ui, |ui| {
                        if ui.selectable_value(&mut self.lang, Lang::En, "English").changed() {
                            save_lang(self.lang);
                        }
                        if ui.selectable_value(&mut self.lang, Lang::Da, "Dansk").changed() {
                            save_lang(self.lang);
                        }
                    });
            });

            // Tabs (the OCR tab exists on Linux only for now)
            if cfg!(target_os = "linux") {
                ui.horizontal(|ui| {
                    ui.selectable_value(&mut self.tab, Tab::Expander, tr(lang, "Text expander", "Tekstudvider"));
                    ui.selectable_value(&mut self.tab, Tab::Ocr, tr(lang, "OCR (text from screen)", "OCR (tekst fra skærm)"));
                    ui.selectable_value(&mut self.tab, Tab::Voice, tr(lang, "Voice typing", "Tale til tekst"));
                    ui.selectable_value(&mut self.tab, Tab::Read, tr(lang, "Read aloud", "Oplæsning"));
                });
            }
            ui.separator();

            match self.tab {
                Tab::Expander => self.ui_expander(ui, lang),
                Tab::Ocr => self.ui_ocr(ui, lang),
                Tab::Voice => self.ui_voice(ui, lang),
                Tab::Read => self.ui_read(ui, lang),
            }
        });
    }
}

// ---------------------------------------------------------------- live text box (voice typing)

#[cfg(target_os = "linux")]
const OVERLAY_W: f32 = 760.0;
#[cfg(target_os = "linux")]
const OVERLAY_H: f32 = 175.0;

#[cfg(target_os = "linux")]
struct Overlay {
    positioned: bool,
}

#[cfg(target_os = "linux")]
impl eframe::App for Overlay {
    fn clear_color(&self, _visuals: &egui::Visuals) -> [f32; 4] {
        [0.0, 0.0, 0.0, 0.0]
    }

    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        ctx.request_repaint_after(Duration::from_millis(100));
        // Bottom centre of the screen
        if !self.positioned {
            if let Some(monitor) = ctx.input(|i| i.viewport().monitor_size) {
                let pos = egui::pos2(
                    (monitor.x - OVERLAY_W) / 2.0,
                    monitor.y - OVERLAY_H - 90.0,
                );
                ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(pos));
                self.positioned = true;
            }
        }
        // The voice typing asked the box to close
        if config_dir().join("voice_close").exists() {
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        }
        let text = fs::read_to_string(config_dir().join("voice_live.txt")).unwrap_or_default();
        let level: f32 = fs::read_to_string(config_dir().join("voice_level.txt"))
            .ok()
            .and_then(|t| t.trim().parse().ok())
            .unwrap_or(0.0);
        let note = fs::read_to_string(config_dir().join("voice_note.txt")).unwrap_or_default();
        let frame = egui::Frame::none()
            .fill(egui::Color32::from_rgba_unmultiplied(25, 25, 25, 235))
            .rounding(12.0)
            .inner_margin(14.0);
        egui::CentralPanel::default().frame(frame).show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.colored_label(egui::Color32::LIGHT_RED, "Listening...");
                ui.add(egui::ProgressBar::new(level.clamp(0.0, 1.0)).desired_width(220.0));
            });
            let shown = if text.trim().is_empty() {
                "...".to_string()
            } else {
                text
            };
            ui.label(egui::RichText::new(shown).size(22.0).color(egui::Color32::WHITE));
            if !note.trim().is_empty() {
                ui.label(egui::RichText::new(note.trim()).size(13.0).color(egui::Color32::GRAY));
            }
        });
    }
}

#[cfg(target_os = "linux")]
fn run_overlay() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([OVERLAY_W, OVERLAY_H])
            .with_decorations(false)
            .with_always_on_top()
            .with_transparent(true)
            .with_mouse_passthrough(true)
            .with_active(false)
            // a notification-type window: the desktop does not give it the keyboard focus
            .with_window_type(egui::X11WindowType::Notification)
            .with_title("Text Expander voice"),
        ..Default::default()
    };
    eframe::run_native(
        "Text Expander voice",
        options,
        Box::new(|_cc| Ok(Box::new(Overlay { positioned: false }))),
    )
}

// ---------------------------------------------------------------- edit box (voice typing)

#[cfg(target_os = "linux")]
struct Review {
    text: String,
    lang: Lang,
    first_frame: bool,
}

#[cfg(target_os = "linux")]
impl eframe::App for Review {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        let lang = self.lang;
        if self.first_frame {
            ctx.send_viewport_cmd(egui::ViewportCommand::Focus);
        }

        // Enter sends, Shift+Enter makes a new line, Esc cancels
        let mut send = false;
        let mut cancel = false;
        ctx.input_mut(|i| {
            if i.consume_key(egui::Modifiers::NONE, egui::Key::Enter) {
                send = true;
            }
            if i.consume_key(egui::Modifiers::NONE, egui::Key::Escape) {
                cancel = true;
            }
        });

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.label(tr(
                lang,
                "Correct the text if needed. Enter = send it to the text field, Shift+Enter = new line, Esc = cancel.",
                "Ret teksten, hvis der er fejl. Enter = send den til tekstfeltet, Shift+Enter = ny linje, Esc = annuller.",
            ));
            let edit = egui::TextEdit::multiline(&mut self.text)
                .desired_width(f32::INFINITY)
                .desired_rows(5)
                .font(egui::FontId::proportional(20.0));
            let response = ui.add(edit);
            if self.first_frame {
                response.request_focus();
            }
            ui.horizontal(|ui| {
                if ui.button(tr(lang, "Send", "Send")).clicked() {
                    send = true;
                }
                if ui.button(tr(lang, "Cancel", "Annuller")).clicked() {
                    cancel = true;
                }
            });
        });
        self.first_frame = false;

        if send {
            let _ = fs::write(config_dir().join("voice_review_out.txt"), &self.text);
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        } else if cancel {
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        }
    }
}

#[cfg(target_os = "linux")]
fn run_review() -> eframe::Result<()> {
    let text = fs::read_to_string(config_dir().join("voice_review_in.txt")).unwrap_or_default();
    let lang = load_lang();
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([780.0, 300.0])
            .with_always_on_top()
            .with_title(tr(lang, "Text Expander - correct and send", "Text Expander - ret og send")),
        ..Default::default()
    };
    eframe::run_native(
        "Text Expander edit",
        options,
        Box::new(move |_cc| {
            Ok(Box::new(Review {
                text,
                lang,
                first_frame: true,
            }))
        }),
    )
}

fn main() -> eframe::Result<()> {
    // Commands for the desktop's own shortcuts: expander --voice-toggle / --voice-start / --voice-stop / --ocr
    #[cfg(target_os = "linux")]
    {
        let args: Vec<String> = std::env::args().collect();
        for (flag, command) in [
            ("--voice-toggle", "voice-toggle"),
            ("--voice-start", "voice-start"),
            ("--voice-stop", "voice-stop"),
            ("--ocr", "ocr"),
            ("--read-da", "read-da"),
            ("--read-en", "read-en"),
            ("--read-stop", "read-stop"),
            ("--read-pause", "read-pause"),
        ] {
            if args.iter().any(|a| a == flag) {
                if !control::send(command) {
                    // the background service is not running: start it and try again
                    start_daemon();
                    thread::sleep(Duration::from_secs(3));
                    control::send(command);
                }
                return Ok(());
            }
        }
    }

    #[cfg(target_os = "linux")]
    if std::env::args().any(|a| a == "--overlay") {
        return run_overlay();
    }

    #[cfg(target_os = "linux")]
    if std::env::args().any(|a| a == "--review") {
        return run_review();
    }

    if std::env::args().any(|a| a == "--daemon") {
        run_daemon();
        return Ok(());
    }

    // Settings window: make sure the background service is running first
    if !daemon_running() {
        start_daemon();
        thread::sleep(Duration::from_millis(400));
    }

    let app = App {
        entries: load(),
        enabled: !paused_flag_path().exists(),
        layout: load_layout(),
        lang: load_lang(),
        running: daemon_running(),
        last_check: Instant::now(),
        new_trigger: String::new(),
        new_text: String::new(),
        new_space: true,
        error: String::new(),
        tab: Tab::Expander,
        ocr: load_ocr(),
        recording: false,
        ocr_hint: String::new(),
        ocr_status: Arc::new(Mutex::new(String::new())),
        ocr_langs: Vec::new(),
        ocr_reqs: Vec::new(),
        ocr_loaded: false,
        voice: load_voice(),
        voice_recording: false,
        voice_hint: String::new(),
        voice_status: Arc::new(Mutex::new(String::new())),
        voice_bench: Arc::new(Mutex::new(String::new())),
        voice_reco: Arc::new(Mutex::new(None)),
        speak: load_speak(),
        speak_recording: None,
        speak_hint: String::new(),
        speak_status: Arc::new(Mutex::new(String::new())),
    };

    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default().with_inner_size([780.0, 740.0]),
        ..Default::default()
    };
    eframe::run_native("Text Expander", options, Box::new(|_cc| Ok(Box::new(app))))
}
